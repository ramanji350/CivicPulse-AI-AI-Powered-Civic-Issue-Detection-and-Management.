import { CivicReport, IssueCategory, PriorityLevel } from '../types';

export interface AIAnalysisResult {
  detectedCategory: IssueCategory;
  confidence: number; // e.g. 92
  suggestedPriority: PriorityLevel;
  impactScore: number; // 0-100
  reasons: string[];
  duplicateMatch?: {
    reportId: string;
    title: string;
    similarityPercent: number;
    distanceNote: string;
  };
  analysisMode: 'Server-Side Model' | 'Multi-Factor Explainable AI Engine';
}

const CATEGORY_KEYWORDS: Record<IssueCategory, string[]> = {
  pothole: ['pothole', 'crater', 'asphalt', 'road', 'street', 'crack', 'pavement', 'tarmac', 'swerve', 'bump'],
  garbage: ['garbage', 'trash', 'waste', 'dumpster', 'overflow', 'bin', 'litter', 'smell', 'odor', 'debris'],
  streetlight: ['streetlight', 'street lamp', 'light', 'dark', 'lamp', 'bulb', 'blackout', 'illumination', 'pole'],
  footpath: ['footpath', 'sidewalk', 'curb', 'pedestrian', 'slab', 'paving', 'tripping', 'walker', 'walkway'],
  water_leak: ['water', 'pipe', 'leak', 'flooding', 'burst', 'drain', 'sewer', 'puddle', 'hydrant', 'gusher'],
  traffic_signal: ['traffic light', 'signal', 'red light', 'intersection', 'blink', 'crossing', 'stoplight'],
  other: ['hazard', 'damage', 'broken', 'municipal', 'safety'],
};

export const analyzeCivicIssue = async (
  description: string,
  selectedCategory: IssueCategory,
  location: string,
  existingReports: CivicReport[]
): Promise<AIAnalysisResult> => {
  // Simulate rapid AI processing delay for realistic UX feedback
  await new Promise((resolve) => setTimeout(resolve, 850));

  const lowerDesc = (description + ' ' + location).toLowerCase();

  // 1. Category Refinement
  let bestCategory = selectedCategory;
  let highestKeywordMatches = 0;

  (Object.keys(CATEGORY_KEYWORDS) as IssueCategory[]).forEach((cat) => {
    const matches = CATEGORY_KEYWORDS[cat].filter((kw) => lowerDesc.includes(kw)).length;
    if (matches > highestKeywordMatches && matches >= 2) {
      highestKeywordMatches = matches;
      bestCategory = cat;
    }
  });

  // 2. ImpactScore Calculation (0-100)
  let score = 50; // Baseline
  const reasons: string[] = [];

  // Severity keywords
  const criticalKeywords = ['emergency', 'crash', 'severe', 'deep', 'burst', 'flood', 'crater', 'swerve', 'school', 'hospital', 'injur', 'collapse'];
  const highKeywords = ['heavy', 'overflow', 'dark', 'tripping', 'hazard', 'blocked', 'metro', 'transit', 'danger', 'broken'];
  const mediumKeywords = ['cracked', 'flickering', 'delay', 'litter', 'smell', 'puddle'];

  const critCount = criticalKeywords.filter(k => lowerDesc.includes(k)).length;
  const highCount = highKeywords.filter(k => lowerDesc.includes(k)).length;
  const medCount = mediumKeywords.filter(k => lowerDesc.includes(k)).length;

  score += critCount * 14;
  score += highCount * 8;
  score += medCount * 4;

  // Location risk factor
  if (lowerDesc.includes('school') || lowerDesc.includes('hospital') || lowerDesc.includes('kindergarten')) {
    score += 15;
    reasons.push('High-vulnerability pedestrian zone (school / healthcare proximity)');
  }
  if (lowerDesc.includes('metro') || lowerDesc.includes('bus') || lowerDesc.includes('highway') || lowerDesc.includes('arterial') || lowerDesc.includes('avenue')) {
    score += 12;
    reasons.push('High-density transit corridor with elevated collision or gridlock potential');
  }
  if (lowerDesc.includes('dark') || lowerDesc.includes('night') || lowerDesc.includes('blackout')) {
    score += 10;
    reasons.push('Substantial reduction in nighttime public safety & visibility');
  }
  if (bestCategory === 'pothole' && (lowerDesc.includes('deep') || lowerDesc.includes('swerve') || lowerDesc.includes('crater'))) {
    score += 12;
    reasons.push('Significant road pavement defect causing evasive vehicular maneuvers');
  }
  if (bestCategory === 'water_leak' && (lowerDesc.includes('burst') || lowerDesc.includes('flood'))) {
    score += 14;
    reasons.push('Continuous municipal resource loss & foundation erosion threat');
  }
  if (bestCategory === 'garbage' && (lowerDesc.includes('overflow') || lowerDesc.includes('food') || lowerDesc.includes('odor'))) {
    score += 10;
    reasons.push('Public sanitation threshold exceeded; vector attraction risk');
  }

  // Cap score between 20 and 98
  score = Math.min(98, Math.max(25, score));

  // Determine Priority Level
  let suggestedPriority: PriorityLevel = 'Medium';
  if (score >= 85) {
    suggestedPriority = 'Critical';
  } else if (score >= 70) {
    suggestedPriority = 'High';
  } else if (score >= 45) {
    suggestedPriority = 'Medium';
  } else {
    suggestedPriority = 'Low';
  }

  if (reasons.length === 0) {
    reasons.push('Standard municipal maintenance queue priority assigned');
    reasons.push('No acute physical risk detected in incident description');
  }

  // 3. CivicCluster Duplicate Detection
  let duplicateMatch: AIAnalysisResult['duplicateMatch'] = undefined;
  const locationTerms = location.toLowerCase().split(/[\s,]+/).filter(w => w.length > 3);

  for (const rep of existingReports) {
    // Skip resolved reports for active duplicates
    const isResolved = rep.status === 'Resolved' || rep.timeline[rep.timeline.length - 1]?.stage === 'Resolved';
    if (isResolved) continue;

    // Same category check
    const sameCategory = rep.category === bestCategory;
    // Location similarity check
    const repLocLower = rep.location.address.toLowerCase();
    const matchingLocationWords = locationTerms.filter(term => repLocLower.includes(term)).length;

    if (sameCategory && matchingLocationWords >= 1) {
      duplicateMatch = {
        reportId: rep.id,
        title: rep.title,
        similarityPercent: 88,
        distanceNote: 'Within ~350m of identical report on ' + rep.location.address.split(',')[0],
      };
      break;
    }
  }

  return {
    detectedCategory: bestCategory,
    confidence: Math.floor(88 + Math.random() * 8), // 88% - 95%
    suggestedPriority,
    impactScore: score,
    reasons,
    duplicateMatch,
    analysisMode: 'Multi-Factor Explainable AI Engine',
  };
};
