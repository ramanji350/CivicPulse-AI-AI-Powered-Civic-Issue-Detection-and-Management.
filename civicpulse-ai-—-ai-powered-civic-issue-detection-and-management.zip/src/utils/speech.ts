import { Language } from '../types';

export const isSpeechSupported = (): boolean => {
  return typeof window !== 'undefined' && 'speechSynthesis' in window && 'SpeechSynthesisUtterance' in window;
};

const LANG_VOICE_CODES: Record<Language, string> = {
  en: 'en-US',
  es: 'es-ES',
  hi: 'hi-IN',
  fr: 'fr-FR',
  de: 'de-DE',
  te: 'te-IN',
};

export const speak = (text: string, lang: Language = 'en'): Promise<void> => {
  return new Promise((resolve) => {
    if (!isSpeechSupported()) {
      resolve();
      return;
    }

    try {
      window.speechSynthesis.cancel(); // Stop any pending speech

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.0;
      utterance.pitch = 1.0;
      utterance.lang = LANG_VOICE_CODES[lang] || 'en-US';

      // Pick matching voice if available
      const voices = window.speechSynthesis.getVoices();
      const targetLang = LANG_VOICE_CODES[lang] || 'en-US';
      const matchedVoice = voices.find(v => v.lang.startsWith(targetLang.substring(0, 2)));
      if (matchedVoice) {
        utterance.voice = matchedVoice;
      }

      utterance.onend = () => resolve();
      utterance.onerror = () => resolve();

      window.speechSynthesis.speak(utterance);
    } catch {
      resolve();
    }
  });
};

export const stopSpeech = (): void => {
  if (isSpeechSupported()) {
    try {
      window.speechSynthesis.cancel();
    } catch {
      // ignore
    }
  }
};
