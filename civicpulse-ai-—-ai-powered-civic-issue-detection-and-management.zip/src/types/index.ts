export type UserRole = 'citizen' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
  department?: string;
}

export type IssueCategory = 
  | 'pothole'
  | 'garbage'
  | 'streetlight'
  | 'footpath'
  | 'water_leak'
  | 'traffic_signal'
  | 'other';

export type PriorityLevel = 'Low' | 'Medium' | 'High' | 'Critical';

export type ReportStatus = 
  | 'Submitted'
  | 'Under Review'
  | 'Assigned'
  | 'In Progress'
  | 'Resolved';

export interface TimelineEvent {
  id: string;
  stage: ReportStatus;
  title: string;
  description: string;
  timestamp: string;
  actor: string;
}

export interface CivicReport {
  id: string;
  title: string;
  description: string;
  category: IssueCategory;
  priority: PriorityLevel;
  status?: ReportStatus;
  impactScore: number; // 0-100
  impactReasons: string[];
  location: {
    address: string;
    coordinates?: {
      lat: number;
      lng: number;
    };
    neighborhood?: string;
  };
  imageUrl?: string;
  resolutionImageUrl?: string;
  resolutionNotes?: string;
  resolvedAt?: string;
  createdAt: string;
  updatedAt: string;
  citizenId: string;
  citizenName: string;
  assignedTeam?: string;
  internalNotes?: string;
  duplicateOf?: string; // ID of primary report if detected as duplicate
  clusterCount?: number;
  timeline: TimelineEvent[];
}

export interface NotificationItem {
  id: string;
  userId: string; // citizen id or 'admin' or 'all'
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'alert';
  reportId?: string;
  read: boolean;
  createdAt: string;
}

export type Language = 'en' | 'es' | 'hi' | 'fr' | 'de' | 'te';
