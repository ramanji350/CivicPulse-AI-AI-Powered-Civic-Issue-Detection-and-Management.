import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { 
  User, 
  CivicReport, 
  NotificationItem, 
  Language, 
  ReportStatus, 
  PriorityLevel, 
  TimelineEvent 
} from '../types';
import { INITIAL_SAMPLE_REPORTS } from '../data/sampleReports';
import { speak } from '../utils/speech';

interface AppContextType {
  currentUser: User | null;
  reports: CivicReport[];
  notifications: NotificationItem[];
  language: Language;
  setLanguage: (lang: Language) => void;
  voiceEnabled: boolean;
  setVoiceEnabled: (enabled: boolean) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedReportForProofPath: CivicReport | null;
  setSelectedReportForProofPath: (rep: CivicReport | null) => void;
  addReport: (newReport: Partial<CivicReport>) => CivicReport;
  updateReportStatus: (
    reportId: string, 
    status: ReportStatus, 
    details?: { 
      assignedTeam?: string; 
      internalNotes?: string; 
      resolutionImage?: string; 
      resolutionNotes?: string; 
      priority?: PriorityLevel; 
    }
  ) => void;
  login: (email: string, role?: 'citizen' | 'admin', name?: string) => void;
  logout: () => void;
  switchRole: (role: 'citizen' | 'admin') => void;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  resetDemoData: () => void;
  showDemoGuide: boolean;
  setShowDemoGuide: (show: boolean) => void;
}

const CITIZEN_DEMO_USER: User = {
  id: 'user-priya-01',
  name: 'Priya Sharma',
  email: 'citizen@civicpulse.org',
  role: 'citizen',
  avatar: 'PS',
};

const ADMIN_DEMO_USER: User = {
  id: 'user-admin-01',
  name: 'Chief Eng. David Vance',
  email: 'admin@civicpulse.org',
  role: 'admin',
  department: 'Municipal Public Works Control Bureau',
  avatar: 'DV',
};

const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-1',
    userId: 'user-priya-01',
    title: 'Work In Progress: 5th Avenue Crater',
    message: 'Road Infrastructure Fast-Response Unit #2 has deployed on-site.',
    type: 'info',
    reportId: 'CP-2026-8941',
    read: false,
    createdAt: new Date(Date.now() - 3600000 * 3).toISOString(),
  },
  {
    id: 'notif-2',
    userId: 'user-priya-01',
    title: 'Report Verified & Resolved: Maple School Sidewalk',
    message: 'Repairs on Public Elementary School #4 walkway have been completed & verified by Inspector Torres.',
    type: 'success',
    reportId: 'CP-2026-8519',
    read: true,
    createdAt: new Date(Date.now() - 3600000 * 20).toISOString(),
  },
  {
    id: 'notif-3',
    userId: 'admin',
    title: 'Critical Water Main Rupture Alert',
    message: 'Report #CP-2026-8402 flagged as Critical ImpactScore 94 on Elm Street.',
    type: 'alert',
    reportId: 'CP-2026-8402',
    read: false,
    createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
  }
];

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEY_REPORTS = 'civicpulse_reports_v1';
const STORAGE_KEY_NOTIFS = 'civicpulse_notifications_v1';
const STORAGE_KEY_USER = 'civicpulse_user_v1';
const STORAGE_KEY_LANG = 'civicpulse_lang_v1';
const STORAGE_KEY_VOICE = 'civicpulse_voice_v1';

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // User state
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_USER);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return CITIZEN_DEMO_USER; // Default to Citizen demo for immediate presentation readiness
  });

  // Reports state (shared between citizen and admin!)
  const [reports, setReports] = useState<CivicReport[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_REPORTS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // fallback
    }
    return INITIAL_SAMPLE_REPORTS;
  });

  // Notifications state
  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_NOTIFS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // fallback
    }
    return INITIAL_NOTIFICATIONS;
  });

  // Language state
  const [language, setLanguageState] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_LANG) as Language;
      if (saved && ['en', 'es', 'hi', 'fr', 'de', 'te'].includes(saved)) return saved;
    } catch {
      // fallback
    }
    return 'en';
  });

  // Voice alerts state
  const [voiceEnabled, setVoiceEnabledState] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_VOICE);
      if (saved !== null) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return true; // Enabled by default
  });

  // Active navigation tab
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  // ProofPath detail modal state
  const [selectedReportForProofPath, setSelectedReportForProofPath] = useState<CivicReport | null>(null);
  // Guided demo bar visibility
  const [showDemoGuide, setShowDemoGuide] = useState<boolean>(true);

  // Sync state to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_REPORTS, JSON.stringify(reports));
    } catch {
      // ignore
    }
  }, [reports]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_NOTIFS, JSON.stringify(notifications));
    } catch {
      // ignore
    }
  }, [notifications]);

  useEffect(() => {
    try {
      if (currentUser) {
        localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(currentUser));
      } else {
        localStorage.removeItem(STORAGE_KEY_USER);
      }
    } catch {
      // ignore
    }
  }, [currentUser]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    try {
      localStorage.setItem(STORAGE_KEY_LANG, lang);
    } catch {
      // ignore
    }
  };

  const setVoiceEnabled = (enabled: boolean) => {
    setVoiceEnabledState(enabled);
    try {
      localStorage.setItem(STORAGE_KEY_VOICE, JSON.stringify(enabled));
    } catch {
      // ignore
    }
  };

  const login = (email: string, role: 'citizen' | 'admin' = 'citizen', name?: string) => {
    const isSpecialAdmin = email.toLowerCase().includes('admin') || role === 'admin';
    const user: User = isSpecialAdmin
      ? {
          ...ADMIN_DEMO_USER,
          email,
          name: name || 'Chief Eng. David Vance',
        }
      : {
          ...CITIZEN_DEMO_USER,
          email,
          name: name || 'Priya Sharma',
        };

    setCurrentUser(user);
    setActiveTab(user.role === 'admin' ? 'allReports' : 'dashboard');
  };

  const logout = () => {
    setCurrentUser(null);
  };

  const switchRole = (role: 'citizen' | 'admin') => {
    if (role === 'admin') {
      setCurrentUser(ADMIN_DEMO_USER);
      setActiveTab('allReports');
      if (voiceEnabled) {
        speak('Switched to Administrator Control Center', language);
      }
    } else {
      setCurrentUser(CITIZEN_DEMO_USER);
      setActiveTab('dashboard');
      if (voiceEnabled) {
        speak('Switched to Citizen Portal', language);
      }
    }
  };

  const addReport = (newReportData: Partial<CivicReport>): CivicReport => {
    const uniqueNumber = Math.floor(1000 + Math.random() * 9000);
    const newId = `CP-2026-${uniqueNumber}`;
    const now = new Date().toISOString();

    const initialEvent: TimelineEvent = {
      id: `t-${Date.now()}`,
      stage: 'Submitted',
      title: 'Incident Registered & Impact Analyzed',
      description: `Report submitted by ${currentUser?.name || 'Citizen'}. AI calculated ImpactScore: ${newReportData.impactScore || 75}/100.`,
      timestamp: now,
      actor: currentUser?.name || 'Citizen',
    };

    const completeReport: CivicReport = {
      id: newId,
      title: newReportData.title || 'Civic Hazard Incident',
      description: newReportData.description || '',
      category: newReportData.category || 'other',
      priority: newReportData.priority || 'Medium',
      impactScore: newReportData.impactScore || 70,
      impactReasons: newReportData.impactReasons || ['Logged in city maintenance queue'],
      location: newReportData.location || { address: 'Sector 4, Central District' },
      imageUrl: newReportData.imageUrl,
      createdAt: now,
      updatedAt: now,
      citizenId: currentUser?.id || 'citizen-guest',
      citizenName: currentUser?.name || 'Citizen Reporter',
      timeline: [initialEvent],
      duplicateOf: newReportData.duplicateOf,
    };

    setReports((prev) => [completeReport, ...prev]);

    // Add notification for citizen
    const newNotif: NotificationItem = {
      id: `notif-${Date.now()}`,
      userId: completeReport.citizenId,
      title: `Report ${newId} Logged`,
      message: `Your report for ${completeReport.category} on ${completeReport.location.address} has been received.`,
      type: 'info',
      reportId: newId,
      read: false,
      createdAt: now,
    };

    // Add admin notification if High or Critical
    const adminNotif: NotificationItem = {
      id: `notif-admin-${Date.now()}`,
      userId: 'admin',
      title: `New Civic Issue: ${newId} (${completeReport.priority})`,
      message: `${completeReport.title} at ${completeReport.location.address}`,
      type: completeReport.priority === 'Critical' ? 'alert' : 'info',
      reportId: newId,
      read: false,
      createdAt: now,
    };

    setNotifications((prev) => [newNotif, adminNotif, ...prev]);

    // Voice announcement
    if (voiceEnabled) {
      speak(`Report ${newId} has been registered with priority ${completeReport.priority}.`, language);
    }

    return completeReport;
  };

  const updateReportStatus = (
    reportId: string, 
    status: ReportStatus, 
    details?: { 
      assignedTeam?: string; 
      internalNotes?: string; 
      resolutionImage?: string; 
      resolutionNotes?: string; 
      priority?: PriorityLevel; 
    }
  ) => {
    const now = new Date().toISOString();

    setReports((prev) =>
      prev.map((rep) => {
        if (rep.id !== reportId) return rep;

        const newEvent: TimelineEvent = {
          id: `t-${Date.now()}`,
          stage: status,
          title: `Status updated to ${status}`,
          description: details?.internalNotes || (status === 'Resolved' ? 'Verified resolution completed with evidence sign-off.' : `Status progressed to ${status} by Municipal Operations.`),
          timestamp: now,
          actor: currentUser?.name || 'Municipal Staff',
        };

        const updated: CivicReport = {
          ...rep,
          status: status as any, // sync
          updatedAt: now,
          assignedTeam: details?.assignedTeam ?? rep.assignedTeam,
          internalNotes: details?.internalNotes ?? rep.internalNotes,
          resolutionImageUrl: details?.resolutionImage ?? rep.resolutionImageUrl,
          resolutionNotes: details?.resolutionNotes ?? rep.resolutionNotes,
          resolvedAt: status === 'Resolved' ? now : rep.resolvedAt,
          priority: details?.priority ?? rep.priority,
          timeline: [...rep.timeline, newEvent],
        };

        return updated;
      })
    );

    // Add notifications for the citizen!
    const targetReport = reports.find((r) => r.id === reportId);
    if (targetReport) {
      const citizenNotif: NotificationItem = {
        id: `notif-status-${Date.now()}`,
        userId: targetReport.citizenId,
        title: `Update on #${reportId}: ${status}`,
        message: details?.resolutionNotes || (status === 'Resolved' ? 'Repairs completed! View before & after evidence in ProofPath.' : `Assigned to ${details?.assignedTeam || targetReport.assignedTeam || 'Maintenance Services'}.`),
        type: status === 'Resolved' ? 'success' : 'info',
        reportId: reportId,
        read: false,
        createdAt: now,
      };

      setNotifications((prev) => [citizenNotif, ...prev]);

      // Trigger spoken status notification
      if (voiceEnabled) {
        speak(`Report ${reportId} status updated to ${status}.`, language);
      }
    }
  };

  const markNotificationRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const markAllNotificationsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const resetDemoData = () => {
    setReports(INITIAL_SAMPLE_REPORTS);
    setNotifications(INITIAL_NOTIFICATIONS);
    localStorage.removeItem(STORAGE_KEY_REPORTS);
    localStorage.removeItem(STORAGE_KEY_NOTIFS);
    if (voiceEnabled) {
      speak('Demo data successfully restored to default state.', language);
    }
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        reports,
        notifications,
        language,
        setLanguage,
        voiceEnabled,
        setVoiceEnabled,
        activeTab,
        setActiveTab,
        selectedReportForProofPath,
        setSelectedReportForProofPath,
        addReport,
        updateReportStatus,
        login,
        logout,
        switchRole,
        markNotificationRead,
        markAllNotificationsRead,
        resetDemoData,
        showDemoGuide,
        setShowDemoGuide,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
