import React, { useState, useRef, useEffect } from 'react';
import { 
  MessageSquare, 
  X, 
  Send, 
  Sparkles, 
  Bot, 
  User, 
  ArrowRight, 
  FileText, 
  CheckCircle2,
  Clock
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { translations } from '../../utils/translations';
import { CivicReport } from '../../types';

interface Message {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  timestamp: string;
  relatedReport?: CivicReport;
}

export const CivicAssistChatbot: React.FC = () => {
  const { 
    reports, 
    currentUser, 
    language, 
    setActiveTab, 
    setSelectedReportForProofPath 
  } = useApp();
  const t = translations[language];

  const [isOpen, setIsOpen] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initial welcome greeting
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'm-1',
      sender: 'bot',
      text: `Hello ${currentUser?.name || 'Resident'}! I am CivicAssist, your smart civic co-pilot. How can I assist you with reporting or tracking city incidents today?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    }
  ]);

  const QUICK_QUESTIONS = [
    'How do I report a pothole?',
    'How can I track my report?',
    'What does High Priority mean?',
    'How do I report overflowing garbage?',
    'Check my latest report status',
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen, isTyping]);

  const handleSendMessage = (textToSend?: string) => {
    const query = (textToSend || inputValue).trim();
    if (!query) return;

    const userMsg: Message = {
      id: `u-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputValue('');
    setIsTyping(true);

    setTimeout(() => {
      setIsTyping(false);
      const lower = query.toLowerCase();
      let botResponse = '';
      let relatedReport: CivicReport | undefined = undefined;

      // Real tracking logic against actual saved reports in database!
      if (lower.includes('track') || lower.includes('status') || lower.includes('check') || lower.includes('latest')) {
        const latestReport = reports[0];
        if (latestReport) {
          const currentStage = latestReport.timeline[latestReport.timeline.length - 1]?.stage || 'Submitted';
          relatedReport = latestReport;
          botResponse = `Your most recent report is #${latestReport.id} ("${latestReport.title}"). Current status is "${currentStage}". Assigned to: ${latestReport.assignedTeam || 'Municipal Dispatch'}. ImpactScore: ${latestReport.impactScore}/100.`;
        } else {
          botResponse = "You don't have any reported incidents in the database yet. Click 'Report Issue' to log your first civic hazard!";
        }
      } else if (lower.includes('pothole') || lower.includes('road')) {
        botResponse = "To report a pothole or road damage: Click 'Report Issue' from the navigation bar, upload or select a road photo, specify the street address, and click 'Analyze Issue with AI'. The system will generate an ImpactScore and dispatch it to Road Works!";
      } else if (lower.includes('garbage') || lower.includes('waste') || lower.includes('dumpster')) {
        botResponse = "For overflowing waste or biohazards: Choose the 'Overflowing Waste & Garbage' category during submission. Our ImpactScore algorithm prioritizes commercial zones and pedestrian hazards for fast sanitization dispatch.";
      } else if (lower.includes('priority') || lower.includes('high') || lower.includes('critical')) {
        botResponse = "Priorities (Low, Medium, High, Critical) are generated transparently by our ImpactScore model based on physical severity, traffic density, and proximity to vulnerable areas like schools or transit hubs. Staff can also adjust it.";
      } else if (lower.includes('duplicate') || lower.includes('cluster')) {
        botResponse = "CivicCluster automatically scans active reports for matching categories and nearby locations. If a duplicate is detected, it links your report to the existing work order without discarding your input.";
      } else {
        botResponse = `I can help you report civic hazards, track work order statuses on ProofPath, or explain municipal SLAs. Try asking: "Check my latest report status" or "How do I report a pothole?".`;
      }

      const botMsg: Message = {
        id: `b-${Date.now()}`,
        sender: 'bot',
        text: botResponse,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        relatedReport,
      };

      setMessages((prev) => [...prev, botMsg]);
    }, 700);
  };

  return (
    <>
      {/* Floating Cyan Action Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-40 p-3.5 rounded-2xl bg-gradient-to-r from-[#00BFFF] to-[#38BDF8] text-[#06111F] shadow-2xl shadow-[#00BFFF]/30 hover:scale-105 active:scale-95 transition-all group flex items-center gap-2"
          title="Open CivicAssist AI Co-Pilot"
        >
          <div className="relative">
            <Bot className="w-6 h-6 text-[#06111F]" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-[#A855F7] rounded-full ring-2 ring-[#06111F] animate-ping" />
          </div>
          <span className="text-xs font-black hidden sm:inline pr-1">
            CivicAssist AI
          </span>
        </button>
      )}

      {/* Expandable Chat Drawer */}
      {isOpen && (
        <div className="fixed bottom-6 right-4 sm:right-6 z-50 w-full max-w-[390px] h-[540px] bg-[#0A1728] border border-[#00BFFF]/40 rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-200">
          
          {/* Header */}
          <div className="px-4 py-3 bg-[#0D1C30] border-b border-[#1A2E46] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-[#00BFFF]/20 border border-[#00BFFF]/40 flex items-center justify-center text-[#00BFFF]">
                <Bot className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                  <span>{t.chatbotTitle}</span>
                  <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-[#00BFFF]/20 text-[#38BDF8] font-mono">
                    Online
                  </span>
                </h4>
                <p className="text-[10px] text-[#64748B]">
                  Context-Aware Public Assistant
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="p-1.5 text-[#9AA4B2] hover:text-white rounded-lg hover:bg-[#14263D] transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Messages Area */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-[#071322]">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-2.5 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {msg.sender === 'bot' && (
                  <div className="w-6 h-6 rounded-lg bg-[#00BFFF]/15 border border-[#00BFFF]/30 text-[#00BFFF] flex items-center justify-center flex-shrink-0 mt-1">
                    <Sparkles className="w-3.5 h-3.5" />
                  </div>
                )}

                <div
                  className={`max-w-[82%] p-3 rounded-2xl text-xs leading-relaxed ${
                    msg.sender === 'user'
                      ? 'bg-[#00BFFF] text-[#06111F] font-medium rounded-tr-none shadow-md'
                      : 'bg-[#101F33] text-[#E2E8F0] border border-[#1A2E46] rounded-tl-none shadow-sm'
                  }`}
                >
                  <p>{msg.text}</p>
                  
                  {/* If report card embedded */}
                  {msg.relatedReport && (
                    <div className="mt-2.5 p-2 rounded-xl bg-[#081527] border border-[#1A2E46] text-[11px] space-y-1">
                      <div className="flex items-center justify-between font-mono font-bold text-[#00BFFF]">
                        <span>{msg.relatedReport.id}</span>
                        <span className="text-[#F59E0B]">{msg.relatedReport.priority}</span>
                      </div>
                      <p className="text-white font-semibold truncate">{msg.relatedReport.title}</p>
                      <button
                        onClick={() => {
                          if (msg.relatedReport) {
                            setSelectedReportForProofPath(msg.relatedReport);
                          }
                        }}
                        className="w-full mt-1 py-1 rounded bg-[#00BFFF]/20 text-[#38BDF8] text-[10px] font-bold hover:bg-[#00BFFF]/30 flex items-center justify-center gap-1 transition-colors"
                      >
                        <Clock className="w-3 h-3" />
                        Open in ProofPath
                      </button>
                    </div>
                  )}

                  <span
                    className={`block text-[9px] mt-1 ${
                      msg.sender === 'user' ? 'text-[#06111F]/70 text-right' : 'text-[#64748B]'
                    }`}
                  >
                    {msg.timestamp}
                  </span>
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="flex gap-2 items-center text-xs text-[#00BFFF]">
                <div className="w-6 h-6 rounded-lg bg-[#00BFFF]/15 flex items-center justify-center">
                  <Bot className="w-3.5 h-3.5" />
                </div>
                <div className="bg-[#101F33] px-3 py-1.5 rounded-full border border-[#1A2E46] flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#00BFFF] animate-bounce" />
                  <span className="w-1.5 h-1.5 rounded-full bg-[#00BFFF] animate-bounce [animation-delay:0.2s]" />
                  <span className="w-1.5 h-1.5 rounded-full bg-[#00BFFF] animate-bounce [animation-delay:0.4s]" />
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick Replies Row */}
          <div className="p-2 bg-[#0B1728] border-t border-[#162A42] overflow-x-auto whitespace-nowrap flex gap-1.5 scrollbar-none">
            {QUICK_QUESTIONS.map((q, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(q)}
                className="px-2.5 py-1 rounded-lg bg-[#0E1F36] hover:bg-[#00BFFF]/20 text-[10px] font-medium text-[#38BDF8] border border-[#1A2E46] hover:border-[#00BFFF]/40 flex-shrink-0 transition-all"
              >
                {q}
              </button>
            ))}
          </div>

          {/* Input Bar */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="p-3 bg-[#0D1C30] border-t border-[#1A2E46] flex items-center gap-2"
          >
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder={t.chatPlaceholder}
              className="flex-1 px-3 py-2 rounded-xl bg-[#071322] border border-[#1A2E46] text-white text-xs placeholder-[#4B5E77] focus:outline-none focus:border-[#00BFFF]"
            />
            <button
              type="submit"
              disabled={!inputValue.trim()}
              className="p-2 rounded-xl bg-[#00BFFF] text-[#06111F] hover:bg-[#38BDF8] disabled:opacity-40 transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

        </div>
      )}
    </>
  );
};
