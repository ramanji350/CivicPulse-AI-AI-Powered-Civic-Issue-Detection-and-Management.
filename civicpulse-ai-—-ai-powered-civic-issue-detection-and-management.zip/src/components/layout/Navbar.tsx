import React, { useState } from 'react';
import { 
  Activity, 
  Volume2, 
  VolumeX, 
  Bell, 
  Globe, 
  UserCheck, 
  ShieldAlert, 
  LogOut, 
  PlusCircle, 
  LayoutDashboard, 
  FileText, 
  BarChart3, 
  Settings as SettingsIcon,
  CheckCircle2,
  X,
  Sparkles
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { translations } from '../../utils/translations';
import { Language } from '../../types';
import { speak } from '../../utils/speech';

export const Navbar: React.FC = () => {
  const { 
    currentUser, 
    logout, 
    switchRole, 
    language, 
    setLanguage, 
    voiceEnabled, 
    setVoiceEnabled, 
    activeTab, 
    setActiveTab,
    notifications,
    markNotificationRead,
    markAllNotificationsRead,
    setSelectedReportForProofPath,
    reports
  } = useApp();

  const [showNotifications, setShowNotifications] = useState(false);
  const [showLangMenu, setShowLangMenu] = useState(false);
  const t = translations[language];

  const unreadNotifications = notifications.filter(n => !n.read);

  const handleTestVoice = () => {
    speak('CivicPulse AI Voice Assistance online. Public safety telemetry operating normally.', language);
  };

  const languagesList: { code: Language; label: string; flag: string }[] = [
    { code: 'en', label: 'English', flag: '🇺🇸' },
    { code: 'es', label: 'Español', flag: '🇪🇸' },
    { code: 'hi', label: 'हिन्दी', flag: '🇮🇳' },
    { code: 'fr', label: 'Français', flag: '🇫🇷' },
    { code: 'de', label: 'Deutsch', flag: '🇩🇪' },
    { code: 'te', label: 'తెలుగు', flag: '🇮🇳' },
  ];

  const handleNotificationClick = (reportId?: string) => {
    if (reportId) {
      const rep = reports.find(r => r.id === reportId);
      if (rep) {
        setSelectedReportForProofPath(rep);
      }
    }
    setShowNotifications(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#081527]/95 backdrop-blur-md border-b border-[#1A2E46] px-4 lg:px-8 py-3">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        
        {/* Brand & Logo */}
        <div className="flex items-center gap-3">
          <div 
            onClick={() => setActiveTab(currentUser?.role === 'admin' ? 'allReports' : 'dashboard')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="relative w-10 h-10 rounded-xl bg-gradient-to-br from-[#00BFFF]/20 via-[#101F33] to-[#A855F7]/30 border border-[#00BFFF]/40 flex items-center justify-center shadow-lg shadow-[#00BFFF]/10 group-hover:border-[#00BFFF] transition-all">
              <Activity className="w-5 h-5 text-[#00BFFF] animate-pulse" />
              <div className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-[#00BFFF] rounded-full ring-2 ring-[#081527] animate-ping" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-bold tracking-tight bg-gradient-to-r from-white via-[#E0F2FE] to-[#00BFFF] bg-clip-text text-transparent">
                  CivicPulse
                </span>
                <span className="text-xs px-2 py-0.5 rounded-full font-mono font-semibold bg-[#00BFFF]/15 text-[#38BDF8] border border-[#00BFFF]/30">
                  AI
                </span>
              </div>
              <p className="text-[11px] text-[#9AA4B2] hidden sm:block font-medium">
                Smart City Incident Intelligence
              </p>
            </div>
          </div>
        </div>

        {/* Center Navigation Links */}
        <nav className="hidden md:flex items-center gap-1.5 bg-[#0B1728] p-1 rounded-xl border border-[#162A42]">
          {currentUser?.role === 'citizen' ? (
            <>
              <button
                onClick={() => setActiveTab('dashboard')}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  activeTab === 'dashboard'
                    ? 'bg-[#00BFFF]/20 text-[#38BDF8] border border-[#00BFFF]/30 shadow-sm'
                    : 'text-[#9AA4B2] hover:text-white hover:bg-[#101F33]'
                }`}
              >
                <LayoutDashboard className="w-3.5 h-3.5" />
                {t.dashboard}
              </button>

              <button
                onClick={() => setActiveTab('report')}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  activeTab === 'report'
                    ? 'bg-gradient-to-r from-[#00BFFF] to-[#38BDF8] text-[#06111F] font-bold shadow-md shadow-[#00BFFF]/20'
                    : 'text-[#38BDF8] bg-[#00BFFF]/10 hover:bg-[#00BFFF]/20 border border-[#00BFFF]/25'
                }`}
              >
                <PlusCircle className="w-3.5 h-3.5" />
                {t.reportIssue}
              </button>

              <button
                onClick={() => setActiveTab('myReports')}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  activeTab === 'myReports'
                    ? 'bg-[#00BFFF]/20 text-[#38BDF8] border border-[#00BFFF]/30'
                    : 'text-[#9AA4B2] hover:text-white hover:bg-[#101F33]'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                {t.myReports}
              </button>

              <button
                onClick={() => setActiveTab('insights')}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  activeTab === 'insights'
                    ? 'bg-[#00BFFF]/20 text-[#38BDF8] border border-[#00BFFF]/30'
                    : 'text-[#9AA4B2] hover:text-white hover:bg-[#101F33]'
                }`}
              >
                <BarChart3 className="w-3.5 h-3.5" />
                {t.insights}
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => setActiveTab('allReports')}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  activeTab === 'allReports'
                    ? 'bg-[#A855F7]/20 text-[#C084FC] border border-[#A855F7]/40 shadow-sm'
                    : 'text-[#9AA4B2] hover:text-white hover:bg-[#101F33]'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                {t.allReports}
              </button>

              <button
                onClick={() => setActiveTab('insights')}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  activeTab === 'insights'
                    ? 'bg-[#A855F7]/20 text-[#C084FC] border border-[#A855F7]/40 shadow-sm'
                    : 'text-[#9AA4B2] hover:text-white hover:bg-[#101F33]'
                }`}
              >
                <BarChart3 className="w-3.5 h-3.5" />
                {t.insights}
              </button>
            </>
          )}

          <button
            onClick={() => setActiveTab('settings')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'settings'
                ? 'bg-[#00BFFF]/20 text-[#38BDF8] border border-[#00BFFF]/30'
                : 'text-[#9AA4B2] hover:text-white hover:bg-[#101F33]'
            }`}
          >
            <SettingsIcon className="w-3.5 h-3.5" />
            {t.settings}
          </button>
        </nav>

        {/* Right Controls: Role Switcher, Voice Toggle, Language, Notifs, Profile */}
        <div className="flex items-center gap-2.5">
          
          {/* Quick Role Switcher for Live Demo */}
          <div className="flex items-center bg-[#0B1728] p-1 rounded-xl border border-[#1B314B] shadow-inner">
            <button
              onClick={() => switchRole('citizen')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all ${
                currentUser?.role === 'citizen'
                  ? 'bg-[#00BFFF] text-[#06111F] shadow-sm'
                  : 'text-[#9AA4B2] hover:text-white'
              }`}
              title="Switch to Citizen View"
            >
              <UserCheck className="w-3 h-3" />
              Citizen
            </button>
            <button
              onClick={() => switchRole('admin')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all ${
                currentUser?.role === 'admin'
                  ? 'bg-[#A855F7] text-white shadow-sm'
                  : 'text-[#9AA4B2] hover:text-white'
              }`}
              title="Switch to Admin Control Center"
            >
              <ShieldAlert className="w-3 h-3" />
              Admin
            </button>
          </div>

          {/* Voice Alerts Toggle & Test */}
          <div className="flex items-center gap-1 bg-[#0B1728] p-1 rounded-xl border border-[#162A42]">
            <button
              onClick={() => setVoiceEnabled(!voiceEnabled)}
              className={`p-1.5 rounded-lg text-xs transition-all ${
                voiceEnabled
                  ? 'bg-[#00BFFF]/20 text-[#38BDF8] border border-[#00BFFF]/30'
                  : 'text-[#64748B] hover:text-[#9AA4B2]'
              }`}
              title={voiceEnabled ? 'Voice Alerts Active' : 'Voice Alerts Muted'}
            >
              {voiceEnabled ? (
                <Volume2 className="w-4 h-4 text-[#00BFFF]" />
              ) : (
                <VolumeX className="w-4 h-4 text-[#64748B]" />
              )}
            </button>

            {voiceEnabled && (
              <button
                onClick={handleTestVoice}
                className="hidden xl:inline-block px-2 py-1 text-[10px] font-semibold text-[#38BDF8] hover:bg-[#101F33] rounded-md transition-colors"
                title="Hear audio sample"
              >
                Test Voice
              </button>
            )}
          </div>

          {/* Language Selector Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowLangMenu(!showLangMenu)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 bg-[#0B1728] hover:bg-[#101F33] border border-[#162A42] rounded-xl text-xs text-[#E2E8F0] transition-colors"
              title="Change Language"
            >
              <Globe className="w-3.5 h-3.5 text-[#00BFFF]" />
              <span className="font-semibold uppercase text-[11px]">{language}</span>
            </button>

            {showLangMenu && (
              <div className="absolute right-0 mt-2 w-44 bg-[#0B1728] border border-[#1A2E46] rounded-xl shadow-2xl py-1 z-50">
                <div className="px-3 py-1.5 text-[10px] uppercase font-bold text-[#64748B] tracking-wider border-b border-[#162A42]">
                  Select Language
                </div>
                {languagesList.map((l) => (
                  <button
                    key={l.code}
                    onClick={() => {
                      setLanguage(l.code);
                      setShowLangMenu(false);
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2 text-xs text-left transition-colors ${
                      language === l.code
                        ? 'bg-[#00BFFF]/15 text-[#38BDF8] font-bold'
                        : 'text-[#9AA4B2] hover:bg-[#101F33] hover:text-white'
                    }`}
                  >
                    <span>{l.flag} {l.label}</span>
                    {language === l.code && <CheckCircle2 className="w-3.5 h-3.5 text-[#00BFFF]" />}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Notifications Center */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative p-2 bg-[#0B1728] hover:bg-[#101F33] border border-[#162A42] rounded-xl text-[#9AA4B2] hover:text-white transition-colors"
              title="Notifications"
            >
              <Bell className="w-4 h-4 text-[#9AA4B2]" />
              {unreadNotifications.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#EF4444] text-white text-[9px] font-bold rounded-full flex items-center justify-center animate-pulse">
                  {unreadNotifications.length}
                </span>
              )}
            </button>

            {/* Notification Flyout */}
            {showNotifications && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-[#0B1728] border border-[#1A2E46] rounded-2xl shadow-2xl p-3 z-50">
                <div className="flex items-center justify-between pb-2 border-b border-[#162A42]">
                  <div className="flex items-center gap-2">
                    <Bell className="w-4 h-4 text-[#00BFFF]" />
                    <span className="text-xs font-bold text-white">Notifications</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-[#00BFFF]/20 text-[#38BDF8] font-mono">
                      {unreadNotifications.length} new
                    </span>
                  </div>
                  {unreadNotifications.length > 0 && (
                    <button
                      onClick={markAllNotificationsRead}
                      className="text-[11px] text-[#38BDF8] hover:underline"
                    >
                      Mark all read
                    </button>
                  )}
                </div>

                <div className="mt-2 max-h-72 overflow-y-auto space-y-2">
                  {notifications.length === 0 ? (
                    <div className="text-center py-6 text-xs text-[#64748B]">
                      No notifications yet
                    </div>
                  ) : (
                    notifications.slice(0, 8).map((notif) => (
                      <div
                        key={notif.id}
                        onClick={() => {
                          markNotificationRead(notif.id);
                          handleNotificationClick(notif.reportId);
                        }}
                        className={`p-2.5 rounded-xl border text-xs cursor-pointer transition-all ${
                          notif.read
                            ? 'bg-[#081527]/50 border-[#122238] text-[#9AA4B2]'
                            : 'bg-[#101F33] border-[#00BFFF]/30 text-white shadow-sm'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <span className="font-semibold text-[12px] flex items-center gap-1.5">
                            {notif.type === 'alert' && <span className="w-2 h-2 rounded-full bg-[#EF4444]" />}
                            {notif.type === 'success' && <span className="w-2 h-2 rounded-full bg-[#22C55E]" />}
                            {notif.type === 'info' && <span className="w-2 h-2 rounded-full bg-[#00BFFF]" />}
                            {notif.title}
                          </span>
                          <span className="text-[10px] text-[#64748B] whitespace-nowrap">
                            {new Date(notif.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <p className="text-[11px] text-[#9AA4B2] mt-1 line-clamp-2">
                          {notif.message}
                        </p>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* User Profile / Logout */}
          <div className="flex items-center gap-2 pl-2 border-l border-[#1A2E46]">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#00BFFF] to-[#A855F7] text-[#06111F] font-bold text-xs flex items-center justify-center shadow-md">
                {currentUser?.avatar || 'CP'}
              </div>
              <div className="hidden lg:block text-left">
                <p className="text-xs font-bold text-white leading-tight">
                  {currentUser?.name || 'Guest User'}
                </p>
                <p className="text-[10px] text-[#38BDF8] capitalize font-medium">
                  {currentUser?.role === 'admin' ? 'Municipal Staff' : 'Verified Resident'}
                </p>
              </div>
            </div>

            <button
              onClick={logout}
              className="p-1.5 text-[#9AA4B2] hover:text-[#EF4444] rounded-lg transition-colors"
              title={t.logout}
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};
