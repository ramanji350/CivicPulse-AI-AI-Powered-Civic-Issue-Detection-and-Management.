import React, { useState } from 'react';
import { 
  Sparkles, 
  ChevronRight, 
  ChevronDown, 
  User, 
  ShieldCheck, 
  UploadCloud, 
  Cpu, 
  Volume2, 
  MessageSquare, 
  CheckCircle,
  X
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const DemoWalkthroughBanner: React.FC = () => {
  const { 
    currentUser, 
    switchRole, 
    setActiveTab, 
    showDemoGuide, 
    setShowDemoGuide 
  } = useApp();

  const [expanded, setExpanded] = useState(false);

  if (!showDemoGuide) return null;

  return (
    <div className="bg-[#091629] border-b border-[#00BFFF]/30 px-4 py-2.5 text-xs">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-3">
        
        {/* Banner Title */}
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-[#00BFFF]/20 text-[#38BDF8] border border-[#00BFFF]/40 font-mono font-bold text-[11px]">
            <Sparkles className="w-3 h-3 text-[#00BFFF] animate-pulse" />
            LIVE DEMO WALKTHROUGH
          </span>
          <span className="text-[#F5F7FA] font-medium hidden sm:inline">
            Follow the 10-step judge inspection pathway to test all features:
          </span>
          <button
            onClick={() => setExpanded(!expanded)}
            className="text-[#38BDF8] hover:text-white underline font-semibold flex items-center gap-1 ml-1"
          >
            {expanded ? 'Hide Steps' : 'View Steps'}
            {expanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
          </button>
        </div>

        {/* Quick Demo Shortcuts */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => {
              switchRole('citizen');
              setActiveTab('report');
            }}
            className="px-2.5 py-1 rounded-md bg-[#00BFFF]/15 hover:bg-[#00BFFF]/25 text-[#38BDF8] border border-[#00BFFF]/30 font-semibold flex items-center gap-1 transition-colors"
          >
            <UploadCloud className="w-3 h-3" />
            1. Report as Citizen
          </button>

          <button
            onClick={() => {
              switchRole('admin');
              setActiveTab('allReports');
            }}
            className="px-2.5 py-1 rounded-md bg-[#A855F7]/15 hover:bg-[#A855F7]/25 text-[#C084FC] border border-[#A855F7]/30 font-semibold flex items-center gap-1 transition-colors"
          >
            <ShieldCheck className="w-3 h-3" />
            2. Review as Admin
          </button>

          <button
            onClick={() => setShowDemoGuide(false)}
            className="text-[#64748B] hover:text-[#9AA4B2] p-1 rounded transition-colors"
            title="Dismiss walkthrough bar"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Expanded Walkthrough Details */}
      {expanded && (
        <div className="mt-3 pt-3 border-t border-[#162A42] max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-2.5 text-[11px]">
          <div className="bg-[#0D1C30] p-2.5 rounded-lg border border-[#1A2E46]">
            <div className="text-[#38BDF8] font-bold flex items-center gap-1 mb-1">
              <span className="w-4 h-4 rounded-full bg-[#00BFFF]/20 flex items-center justify-center text-[10px]">1</span>
              Citizen Login
            </div>
            <p className="text-[#9AA4B2]">Sign in as Priya Sharma (Citizen demo). View dashboard stats and reports.</p>
          </div>

          <div className="bg-[#0D1C30] p-2.5 rounded-lg border border-[#1A2E46]">
            <div className="text-[#38BDF8] font-bold flex items-center gap-1 mb-1">
              <span className="w-4 h-4 rounded-full bg-[#00BFFF]/20 flex items-center justify-center text-[10px]">2</span>
              Report & AI Analyze
            </div>
            <p className="text-[#9AA4B2]">Upload or pick sample photo, click "Analyze Issue" to see ImpactScore (0-100) & CivicCluster check.</p>
          </div>

          <div className="bg-[#0D1C30] p-2.5 rounded-lg border border-[#1A2E46]">
            <div className="text-[#38BDF8] font-bold flex items-center gap-1 mb-1">
              <span className="w-4 h-4 rounded-full bg-[#00BFFF]/20 flex items-center justify-center text-[10px]">3</span>
              Voice & Chatbot
            </div>
            <p className="text-[#9AA4B2]">Hear audio speech confirmation. Ask CivicAssist chatbot to track your new report ID.</p>
          </div>

          <div className="bg-[#0D1C30] p-2.5 rounded-lg border border-[#1A2E46]">
            <div className="text-[#A855F7] font-bold flex items-center gap-1 mb-1">
              <span className="w-4 h-4 rounded-full bg-[#A855F7]/20 flex items-center justify-center text-[10px]">4</span>
              Admin Triage & Assign
            </div>
            <p className="text-[#9AA4B2]">Switch to Admin in 1-click. Assign team, advance status to Resolved with proof photo.</p>
          </div>

          <div className="bg-[#0D1C30] p-2.5 rounded-lg border border-[#1A2E46]">
            <div className="text-[#22C55E] font-bold flex items-center gap-1 mb-1">
              <span className="w-4 h-4 rounded-full bg-[#22C55E]/20 flex items-center justify-center text-[10px]">5</span>
              ProofPath Verification
            </div>
            <p className="text-[#9AA4B2]">Switch back to Citizen: verify updated status, notification, and before/after ProofPath timeline.</p>
          </div>
        </div>
      )}
    </div>
  );
};
