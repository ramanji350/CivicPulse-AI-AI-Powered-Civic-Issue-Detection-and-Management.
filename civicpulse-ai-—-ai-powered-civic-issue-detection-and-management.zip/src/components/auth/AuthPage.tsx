import React, { useState } from 'react';
import { 
  Activity, 
  Eye, 
  EyeOff, 
  ShieldCheck, 
  Sparkles, 
  CheckCircle2, 
  MapPin, 
  Cpu, 
  Layers, 
  ArrowRight,
  UserCheck
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { translations } from '../../utils/translations';

export const AuthPage: React.FC = () => {
  const { login, language } = useApp();
  const t = translations[language];

  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');

    if (!email || !email.includes('@')) {
      setError('Please enter a valid email address.');
      return;
    }

    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      // Regular user cannot grant themselves admin role!
      // If signing up, role is strictly citizen. If signing in with 'admin@civicpulse.org', admin login is allowed.
      const isOfficialAdmin = email.trim().toLowerCase() === 'admin@civicpulse.org';
      login(email, isOfficialAdmin ? 'admin' : 'citizen', name || (isOfficialAdmin ? 'Chief Eng. David Vance' : 'Citizen Resident'));
    }, 600);
  };

  const handleQuickDemoCitizen = () => {
    setEmail('citizen@civicpulse.org');
    setPassword('demoCitizen2026!');
    login('citizen@civicpulse.org', 'citizen', 'Priya Sharma');
  };

  const handleQuickDemoAdmin = () => {
    setEmail('admin@civicpulse.org');
    setPassword('adminSecured2026!');
    login('admin@civicpulse.org', 'admin', 'Chief Eng. David Vance');
  };

  return (
    <div className="min-h-screen bg-[#06111F] flex items-center justify-center p-4 sm:p-6 lg:p-12 relative overflow-hidden">
      
      {/* Background Smart-City Grid & Glows */}
      <div className="absolute inset-0 smart-city-grid opacity-60 pointer-events-none" />
      <div className="absolute top-1/4 left-10 w-96 h-96 bg-[#00BFFF]/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-[#A855F7]/10 rounded-full blur-3xl pointer-events-none" />

      {/* Main 2-Panel Container */}
      <div className="relative w-full max-w-5xl rounded-3xl border border-[#162C47] bg-[#0A1628]/90 backdrop-blur-xl shadow-2xl grid grid-cols-1 lg:grid-cols-12 overflow-hidden z-10">
        
        {/* LEFT PANEL: Smart City Branding & Illustration */}
        <div className="lg:col-span-7 p-8 sm:p-12 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-[#162C47] relative bg-gradient-to-br from-[#0B1A2E] via-[#091526] to-[#06111F]">
          
          {/* Logo & Tagline */}
          <div>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[#00BFFF]/20 via-[#101F33] to-[#A855F7]/30 border border-[#00BFFF]/40 flex items-center justify-center shadow-lg shadow-[#00BFFF]/15">
                <Activity className="w-6 h-6 text-[#00BFFF] animate-pulse" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-2xl font-black tracking-tight text-white">
                    CivicPulse <span className="text-[#00BFFF]">AI</span>
                  </h1>
                </div>
                <p className="text-xs font-mono text-[#38BDF8]">
                  Smart-City Intelligence Engine
                </p>
              </div>
            </div>

            <p className="text-sm text-[#00BFFF] font-semibold tracking-wide uppercase mt-4">
              "{t.tagline}"
            </p>
          </div>

          {/* Futuristic Smart City SVG Graphic */}
          <div className="my-8 relative py-4 flex items-center justify-center">
            <svg
              className="w-full max-w-md h-52 sm:h-60"
              viewBox="0 0 500 240"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              {/* Skyline silhouette */}
              <rect x="30" y="90" width="45" height="130" rx="3" fill="#0D1E33" stroke="#162E4C" stroke-width="1.5"/>
              <rect x="85" y="60" width="55" height="160" rx="3" fill="#102540" stroke="#1D3C63" stroke-width="1.5"/>
              <rect x="150" y="110" width="40" height="110" rx="3" fill="#0D1E33" stroke="#162E4C" stroke-width="1.5"/>
              <rect x="200" y="40" width="70" height="180" rx="4" fill="#132B4A" stroke="#00BFFF" stroke-width="1.5" stroke-opacity="0.6"/>
              <rect x="280" y="80" width="50" height="140" rx="3" fill="#0D1E33" stroke="#162E4C" stroke-width="1.5"/>
              <rect x="340" y="50" width="60" height="170" rx="3" fill="#102540" stroke="#A855F7" stroke-width="1.5" stroke-opacity="0.6"/>
              <rect x="410" y="100" width="55" height="120" rx="3" fill="#0D1E33" stroke="#162E4C" stroke-width="1.5"/>

              {/* Glowing windows */}
              <circle cx="225" cy="65" r="2.5" fill="#00BFFF"/>
              <circle cx="245" cy="65" r="2.5" fill="#38BDF8"/>
              <circle cx="225" cy="85" r="2.5" fill="#38BDF8"/>
              <circle cx="245" cy="85" r="2.5" fill="#00BFFF"/>
              <circle cx="360" cy="75" r="2.5" fill="#A855F7"/>
              <circle cx="380" cy="75" r="2.5" fill="#E879F9"/>

              {/* Connected Telemetry Network Line */}
              <path d="M50 170 Q 150 120 235 90 T 370 110 T 450 160" stroke="#00BFFF" stroke-width="2" stroke-dasharray="6,6" stroke-opacity="0.7"/>
              <path d="M70 210 Q 235 150 430 210" stroke="#A855F7" stroke-width="1.5" stroke-opacity="0.5"/>

              {/* Glowing Pulse Nodes */}
              <circle cx="235" cy="90" r="7" fill="#00BFFF" fill-opacity="0.3"/>
              <circle cx="235" cy="90" r="4" fill="#00BFFF"/>
              <circle cx="370" cy="110" r="7" fill="#A855F7" fill-opacity="0.3"/>
              <circle cx="370" cy="110" r="4" fill="#A855F7"/>

              {/* Road Grid Base */}
              <line x1="20" y1="220" x2="480" y2="220" stroke="#00BFFF" stroke-width="2.5" stroke-opacity="0.8"/>
              <line x1="20" y1="230" x2="480" y2="230" stroke="#162E4C" stroke-width="1.5"/>
            </svg>
          </div>

          {/* Heading & 3 Highlights */}
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-white mb-2">
              {t.letBuild}
            </h2>
            <p className="text-xs sm:text-sm text-[#9AA4B2] mb-6 leading-relaxed">
              {t.subDescription}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-4 border-t border-[#162A42]">
              <div className="bg-[#0E1F36]/80 p-3 rounded-xl border border-[#18314F]">
                <Cpu className="w-4 h-4 text-[#00BFFF] mb-1.5" />
                <h4 className="text-xs font-bold text-white">AI-Assisted Vision</h4>
                <p className="text-[11px] text-[#9AA4B2]">Rapid hazard classification & severity scoring</p>
              </div>

              <div className="bg-[#0E1F36]/80 p-3 rounded-xl border border-[#18314F]">
                <Layers className="w-4 h-4 text-[#A855F7] mb-1.5" />
                <h4 className="text-xs font-bold text-white">Smart Prioritization</h4>
                <p className="text-[11px] text-[#9AA4B2]">Explainable ImpactScore matrix (0-100)</p>
              </div>

              <div className="bg-[#0E1F36]/80 p-3 rounded-xl border border-[#18314F]">
                <CheckCircle2 className="w-4 h-4 text-[#22C55E] mb-1.5" />
                <h4 className="text-xs font-bold text-white">ProofPath Tracking</h4>
                <p className="text-[11px] text-[#9AA4B2]">Verified before & after resolution trail</p>
              </div>
            </div>
          </div>

        </div>

        {/* RIGHT PANEL: Dark Glass Login Card */}
        <div className="lg:col-span-5 p-8 sm:p-12 flex flex-col justify-center bg-[#0B1728]/95 relative">
          
          <div className="max-w-sm mx-auto w-full">
            
            {/* Tab switch: Sign In vs Sign Up */}
            <div className="flex bg-[#071322] p-1 rounded-2xl border border-[#162C47] mb-6">
              <button
                type="button"
                onClick={() => { setMode('signin'); setError(''); }}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
                  mode === 'signin'
                    ? 'bg-[#00BFFF] text-[#06111F] shadow-md shadow-[#00BFFF]/20'
                    : 'text-[#9AA4B2] hover:text-white'
                }`}
              >
                {t.signIn}
              </button>
              <button
                type="button"
                onClick={() => { setMode('signup'); setError(''); }}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
                  mode === 'signup'
                    ? 'bg-[#00BFFF] text-[#06111F] shadow-md shadow-[#00BFFF]/20'
                    : 'text-[#9AA4B2] hover:text-white'
                }`}
              >
                {t.signUp}
              </button>
            </div>

            <div className="mb-6">
              <h3 className="text-lg font-bold text-white">
                {mode === 'signin' ? t.loginTitle : t.createAccount}
              </h3>
              <p className="text-xs text-[#9AA4B2] mt-1">
                {mode === 'signin' 
                  ? 'Access your citizen reporting dashboard or staff control desk.'
                  : 'Register as a verified city resident to report civic hazards.'}
              </p>
            </div>

            {/* Error / Success alert */}
            {error && (
              <div className="mb-4 p-3 rounded-xl bg-[#EF4444]/15 border border-[#EF4444]/40 text-[#EF4444] text-xs font-medium">
                {error}
              </div>
            )}
            {successMsg && (
              <div className="mb-4 p-3 rounded-xl bg-[#22C55E]/15 border border-[#22C55E]/40 text-[#22C55E] text-xs font-medium">
                {successMsg}
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleAuthSubmit} className="space-y-4">
              
              {mode === 'signup' && (
                <div>
                  <label className="block text-xs font-semibold text-[#CBD5E1] mb-1.5">
                    Full Name
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Priya Sharma"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#071322] border border-[#1A2E46] text-white text-xs placeholder-[#4B5E77] focus:outline-none focus:border-[#00BFFF] focus:ring-1 focus:ring-[#00BFFF] transition-all"
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-[#CBD5E1] mb-1.5">
                  {t.emailLabel}
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="resident@city.gov or email@domain.com"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#071322] border border-[#1A2E46] text-white text-xs placeholder-[#4B5E77] focus:outline-none focus:border-[#00BFFF] focus:ring-1 focus:ring-[#00BFFF] transition-all"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#CBD5E1] mb-1.5">
                  {t.passwordLabel}
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#071322] border border-[#1A2E46] text-white text-xs placeholder-[#4B5E77] focus:outline-none focus:border-[#00BFFF] focus:ring-1 focus:ring-[#00BFFF] transition-all pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-[#64748B] hover:text-[#CBD5E1]"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#00BFFF] to-[#38BDF8] text-[#06111F] font-bold text-xs shadow-lg shadow-[#00BFFF]/20 hover:opacity-95 active:scale-[0.99] transition-all flex items-center justify-center gap-2"
              >
                {loading ? (
                  <span className="inline-block w-4 h-4 border-2 border-[#06111F] border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <span>{mode === 'signin' ? t.signIn : t.signUp}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </>
                )}
              </button>
            </form>

            {/* Quick Demo Logins Section */}
            <div className="mt-8 pt-6 border-t border-[#162A42]">
              <div className="text-center mb-3">
                <span className="text-[11px] font-semibold text-[#64748B] uppercase tracking-wider">
                  Live Judge Demonstration Options
                </span>
              </div>

              <div className="space-y-2">
                <button
                  type="button"
                  onClick={handleQuickDemoCitizen}
                  className="w-full py-2 px-3 rounded-xl bg-[#071322] hover:bg-[#101F33] border border-[#00BFFF]/30 text-xs font-semibold text-[#38BDF8] flex items-center justify-between group transition-all"
                >
                  <div className="flex items-center gap-2">
                    <UserCheck className="w-4 h-4 text-[#00BFFF]" />
                    <span>{t.demoCitizenLogin} (Priya Sharma)</span>
                  </div>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#00BFFF]/10 text-[#00BFFF]">
                    Resident
                  </span>
                </button>

                <button
                  type="button"
                  onClick={handleQuickDemoAdmin}
                  className="w-full py-2 px-3 rounded-xl bg-[#071322] hover:bg-[#101F33] border border-[#A855F7]/30 text-xs font-semibold text-[#C084FC] flex items-center justify-between group transition-all"
                >
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-[#A855F7]" />
                    <span>{t.demoAdminLogin} (Chief Eng. Vance)</span>
                  </div>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#A855F7]/10 text-[#C084FC]">
                    Municipal Staff
                  </span>
                </button>
              </div>

              <p className="text-[10px] text-center text-[#4B5E77] mt-3">
                Demo accounts provide persistent browser storage with pre-seeded civic telemetry.
              </p>
            </div>

          </div>

        </div>

      </div>

    </div>
  );
};
