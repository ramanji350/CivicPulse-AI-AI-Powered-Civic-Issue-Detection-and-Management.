import React, { useState } from 'react';
import { 
  FileText, 
  Search, 
  Filter, 
  MapPin, 
  Calendar, 
  ArrowRight, 
  PlusCircle, 
  AlertTriangle,
  Clock
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { translations } from '../../utils/translations';
import { IssueCategory, ReportStatus, PriorityLevel } from '../../types';

export const MyReportsView: React.FC = () => {
  const { 
    reports, 
    language, 
    setActiveTab, 
    setSelectedReportForProofPath 
  } = useApp();
  const t = translations[language];

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const filteredReports = reports.filter((rep) => {
    const currentStage = rep.timeline[rep.timeline.length - 1]?.stage || 'Submitted';
    const matchesSearch = 
      rep.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rep.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rep.location.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rep.id.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = selectedStatus === 'all' || currentStage === selectedStatus;
    const matchesCategory = selectedCategory === 'all' || rep.category === selectedCategory;

    return matchesSearch && matchesStatus && matchesCategory;
  });

  const getPriorityBadgeClass = (priority: PriorityLevel) => {
    switch (priority) {
      case 'Critical':
        return 'bg-[#EF4444]/20 text-[#EF4444] border-[#EF4444]/40';
      case 'High':
        return 'bg-[#F59E0B]/20 text-[#F59E0B] border-[#F59E0B]/40';
      case 'Medium':
        return 'bg-[#38BDF8]/20 text-[#38BDF8] border-[#38BDF8]/40';
      default:
        return 'bg-[#22C55E]/20 text-[#22C55E] border-[#22C55E]/40';
    }
  };

  const getStatusBadgeClass = (status: ReportStatus) => {
    switch (status) {
      case 'Resolved':
        return 'bg-[#22C55E]/20 text-[#22C55E] border-[#22C55E]/40';
      case 'In Progress':
        return 'bg-[#00BFFF]/20 text-[#38BDF8] border-[#00BFFF]/40';
      case 'Assigned':
        return 'bg-[#A855F7]/20 text-[#C084FC] border-[#A855F7]/40';
      case 'Under Review':
        return 'bg-[#F59E0B]/20 text-[#F59E0B] border-[#F59E0B]/40';
      default:
        return 'bg-[#9AA4B2]/20 text-[#CBD5E1] border-[#9AA4B2]/40';
    }
  };

  return (
    <div className="max-w-7xl mx-auto py-6 px-4 lg:px-8 space-y-6">
      
      {/* Header & CTA */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-white">
            {t.myReports}
          </h1>
          <p className="text-xs text-[#9AA4B2] mt-1">
            Review all civic incidents submitted by residents with transparent ProofPath audit trails.
          </p>
        </div>

        <button
          onClick={() => setActiveTab('report')}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#00BFFF] to-[#38BDF8] text-[#06111F] font-bold text-xs shadow-md shadow-[#00BFFF]/20 flex items-center justify-center gap-2 hover:opacity-95 transition-all self-start sm:self-auto"
        >
          <PlusCircle className="w-4 h-4" />
          {t.reportCivicIssue}
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-[#0B1728] p-4 rounded-2xl border border-[#162A42] flex flex-col md:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-[#64748B] absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by report ID, street name, description..."
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-[#071322] border border-[#1A2E46] text-white text-xs placeholder-[#4B5E77] focus:outline-none focus:border-[#00BFFF]"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="flex-1 md:w-40 px-3 py-2 rounded-xl bg-[#071322] border border-[#1A2E46] text-white text-xs focus:outline-none focus:border-[#00BFFF]"
          >
            <option value="all">All Statuses</option>
            <option value="Submitted">Submitted</option>
            <option value="Under Review">Under Review</option>
            <option value="Assigned">Assigned</option>
            <option value="In Progress">In Progress</option>
            <option value="Resolved">Resolved</option>
          </select>

          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="flex-1 md:w-44 px-3 py-2 rounded-xl bg-[#071322] border border-[#1A2E46] text-white text-xs focus:outline-none focus:border-[#00BFFF]"
          >
            <option value="all">All Categories</option>
            <option value="pothole">Potholes & Roads</option>
            <option value="garbage">Waste & Dumpsters</option>
            <option value="streetlight">Streetlights</option>
            <option value="footpath">Footpaths & Sidewalks</option>
            <option value="water_leak">Water Leaks</option>
            <option value="other">Other Hazards</option>
          </select>
        </div>
      </div>

      {/* Reports Grid */}
      {filteredReports.length === 0 ? (
        <div className="bg-[#0B1728] rounded-2xl border border-[#162A42] p-12 text-center">
          <Clock className="w-12 h-12 text-[#64748B] mx-auto mb-3" />
          <h3 className="text-sm font-bold text-white">No Matching Reports Found</h3>
          <p className="text-xs text-[#9AA4B2] mt-1">Try modifying your search or filter criteria.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredReports.map((rep) => {
            const currentStage = rep.timeline[rep.timeline.length - 1]?.stage || 'Submitted';
            return (
              <div 
                key={rep.id}
                className="bg-[#0B1728] rounded-2xl border border-[#162A42] hover:border-[#00BFFF]/40 transition-all shadow-lg flex flex-col justify-between overflow-hidden group"
              >
                <div>
                  {/* Card Image Banner */}
                  <div className="h-44 bg-[#06111F] relative overflow-hidden border-b border-[#162A42]">
                    {rep.imageUrl ? (
                      <img
                        src={rep.imageUrl}
                        alt={rep.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-xs text-[#64748B]">
                        No image attached
                      </div>
                    )}

                    {/* Floating Badges */}
                    <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                      <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded-md bg-[#06111F]/80 backdrop-blur-md text-[#00BFFF] border border-[#00BFFF]/40">
                        {rep.id}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border backdrop-blur-md ${getPriorityBadgeClass(rep.priority)}`}>
                        {rep.priority}
                      </span>
                    </div>

                    <div className="absolute top-2.5 right-2.5">
                      <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border backdrop-blur-md ${getStatusBadgeClass(currentStage)}`}>
                        {currentStage}
                      </span>
                    </div>

                    {rep.duplicateOf && (
                      <div className="absolute bottom-2 left-2 right-2 bg-[#F59E0B]/90 backdrop-blur-md text-[#06111F] text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" />
                        CivicCluster: Clustered with {rep.duplicateOf}
                      </div>
                    )}
                  </div>

                  {/* Card Content */}
                  <div className="p-4 space-y-2">
                    <h3 className="text-sm font-bold text-white group-hover:text-[#38BDF8] transition-colors line-clamp-1">
                      {rep.title}
                    </h3>
                    <p className="text-xs text-[#9AA4B2] line-clamp-2 leading-relaxed">
                      {rep.description}
                    </p>

                    <div className="pt-2 border-t border-[#122238] space-y-1 text-[11px] text-[#9AA4B2]">
                      <div className="flex items-center gap-1.5 truncate">
                        <MapPin className="w-3.5 h-3.5 text-[#00BFFF] flex-shrink-0" />
                        <span className="truncate">{rep.location.address}</span>
                      </div>
                      <div className="flex items-center justify-between text-[10px] text-[#64748B] pt-1">
                        <span>Submitted: {new Date(rep.createdAt).toLocaleDateString()}</span>
                        <span className="font-mono text-[#00BFFF] font-bold">ImpactScore: {rep.impactScore}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Footer Action */}
                <div className="p-4 pt-0">
                  <button
                    onClick={() => setSelectedReportForProofPath(rep)}
                    className="w-full py-2 rounded-xl bg-[#101F33] hover:bg-[#00BFFF]/20 text-[#38BDF8] border border-[#1E3A5F] hover:border-[#00BFFF]/50 text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
                  >
                    <span>View ProofPath Trail</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
