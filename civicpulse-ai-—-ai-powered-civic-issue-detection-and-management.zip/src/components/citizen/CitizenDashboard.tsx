import React from 'react';
import { 
  FileText, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  PlusCircle, 
  TrendingUp, 
  MapPin, 
  Sparkles, 
  ArrowRight,
  ShieldCheck,
  Calendar,
  Layers,
  ChevronRight
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { translations } from '../../utils/translations';
import { IssueCategory, ReportStatus, PriorityLevel } from '../../types';

export const CitizenDashboard: React.FC = () => {
  const { 
    currentUser, 
    reports, 
    language, 
    setActiveTab, 
    setSelectedReportForProofPath 
  } = useApp();
  const t = translations[language];

  // Derive stats from actual reports data
  const totalReportsCount = reports.length;
  const submittedCount = reports.filter(r => r.timeline[r.timeline.length - 1]?.stage === 'Submitted').length;
  const inProgressCount = reports.filter(r => ['Under Review', 'Assigned', 'In Progress'].includes(r.timeline[r.timeline.length - 1]?.stage)).length;
  const resolvedCount = reports.filter(r => r.timeline[r.timeline.length - 1]?.stage === 'Resolved').length;

  // Category counts
  const categoriesList: IssueCategory[] = ['pothole', 'garbage', 'streetlight', 'footpath', 'water_leak', 'other'];
  const categoryCounts = categoriesList.map(cat => ({
    cat,
    label: t.categories[cat] || cat,
    count: reports.filter(r => r.category === cat).length
  }));

  // Status counts
  const statusCounts = [
    { label: t.submitted, count: submittedCount, color: '#9AA4B2' },
    { label: t.underReview, count: reports.filter(r => r.timeline[r.timeline.length - 1]?.stage === 'Under Review').length, color: '#F59E0B' },
    { label: t.inProgress, count: inProgressCount, color: '#00BFFF' },
    { label: t.resolved, count: resolvedCount, color: '#22C55E' },
  ];

  const getPriorityBadge = (priority: PriorityLevel) => {
    switch (priority) {
      case 'Critical':
        return 'bg-[#EF4444]/20 text-[#EF4444] border-[#EF4444]/40';
      case 'High':
        return 'bg-[#F59E0B]/20 text-[#F59E0B] border-[#F59E0B]/40';
      case 'Medium':
        return 'bg-[#38BDF8]/20 text-[#38BDF8] border-[#38BDF8]/40';
      default:
        return 'bg-[#22C55E]/20 text-[#22C55E] border-[#22C55E]/40';
    }
  };

  const getStatusBadge = (status: ReportStatus) => {
    switch (status) {
      case 'Resolved':
        return 'bg-[#22C55E]/20 text-[#22C55E] border-[#22C55E]/40';
      case 'In Progress':
        return 'bg-[#00BFFF]/20 text-[#38BDF8] border-[#00BFFF]/40';
      case 'Assigned':
        return 'bg-[#A855F7]/20 text-[#C084FC] border-[#A855F7]/40';
      case 'Under Review':
        return 'bg-[#F59E0B]/20 text-[#F59E0B] border-[#F59E0B]/40';
      default:
        return 'bg-[#9AA4B2]/20 text-[#CBD5E1] border-[#9AA4B2]/40';
    }
  };

  return (
    <div className="max-w-7xl mx-auto py-6 px-4 lg:px-8 space-y-6">
      
      {/* Welcome Banner */}
      <div className="relative rounded-3xl bg-gradient-to-r from-[#0B1E35] via-[#09172A] to-[#101F33] border border-[#162C47] p-6 sm:p-8 overflow-hidden shadow-xl">
        <div className="absolute -right-10 -bottom-10 w-72 h-72 bg-[#00BFFF]/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[11px] font-mono px-2.5 py-0.5 rounded-full bg-[#00BFFF]/15 text-[#38BDF8] border border-[#00BFFF]/30 font-bold">
                MUNICIPAL TELEMETRY ONLINE
              </span>
              <span className="text-xs text-[#9AA4B2]">
                • Sector 4 Civic District
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Welcome back, <span className="bg-gradient-to-r from-[#38BDF8] to-[#00BFFF] bg-clip-text text-transparent">{currentUser?.name || 'Resident'}</span>
            </h1>
            <p className="text-xs sm:text-sm text-[#9AA4B2] mt-1 max-w-xl">
              Track your reported hazards, monitor repair dispatch in real time, and contribute to a safer, smarter neighborhood.
            </p>
          </div>

          {/* Prominent Animated Report Button */}
          <button
            onClick={() => setActiveTab('report')}
            className="flex-shrink-0 px-6 py-3.5 rounded-2xl bg-gradient-to-r from-[#00BFFF] via-[#38BDF8] to-[#00BFFF] text-[#06111F] font-extrabold text-sm shadow-xl shadow-[#00BFFF]/25 hover:shadow-[#00BFFF]/40 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2.5 group"
          >
            <PlusCircle className="w-5 h-5 group-hover:rotate-90 transition-transform duration-300" />
            <span>{t.reportCivicIssue}</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>

      {/* 4 Statistics Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-[#0B1728] p-5 rounded-2xl border border-[#162A42] shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#9AA4B2]">{t.totalReports}</span>
            <div className="w-8 h-8 rounded-xl bg-[#00BFFF]/15 text-[#00BFFF] flex items-center justify-center">
              <FileText className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-white font-mono">{totalReportsCount}</span>
            <span className="text-[11px] text-[#38BDF8]">in database</span>
          </div>
        </div>

        <div className="bg-[#0B1728] p-5 rounded-2xl border border-[#162A42] shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#9AA4B2]">{t.submitted}</span>
            <div className="w-8 h-8 rounded-xl bg-[#9AA4B2]/15 text-[#9AA4B2] flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-white font-mono">{submittedCount}</span>
            <span className="text-[11px] text-[#9AA4B2]">awaiting triage</span>
          </div>
        </div>

        <div className="bg-[#0B1728] p-5 rounded-2xl border border-[#162A42] shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#9AA4B2]">{t.inProgress}</span>
            <div className="w-8 h-8 rounded-xl bg-[#00BFFF]/15 text-[#00BFFF] flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-[#00BFFF] font-mono">{inProgressCount}</span>
            <span className="text-[11px] text-[#38BDF8]">crews on-site</span>
          </div>
        </div>

        <div className="bg-[#0B1728] p-5 rounded-2xl border border-[#162A42] shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#9AA4B2]">{t.resolved}</span>
            <div className="w-8 h-8 rounded-xl bg-[#22C55E]/15 text-[#22C55E] flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-[#22C55E] font-mono">{resolvedCount}</span>
            <span className="text-[11px] text-[#22C55E]">verified closed</span>
          </div>
        </div>

      </div>

      {/* Distribution Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Category Breakdown */}
        <div className="bg-[#0B1728] p-5 rounded-2xl border border-[#162A42] shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-[#00BFFF]" />
              {t.categoryDistribution}
            </h3>
            <span className="text-[11px] text-[#64748B]">Current Live Data</span>
          </div>

          <div className="space-y-3">
            {categoryCounts.map(({ cat, label, count }) => {
              const pct = totalReportsCount > 0 ? Math.round((count / totalReportsCount) * 100) : 0;
              return (
                <div key={cat} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-[#CBD5E1] font-medium">{label}</span>
                    <span className="text-[#9AA4B2] font-mono">{count} ({pct}%)</span>
                  </div>
                  <div className="w-full bg-[#071322] h-2 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-[#00BFFF] to-[#38BDF8]"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Status Breakdown & Impact Meter */}
        <div className="bg-[#0B1728] p-5 rounded-2xl border border-[#162A42] shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#A855F7]" />
                {t.statusDistribution}
              </h3>
              <span className="text-[11px] text-[#64748B]">Resolution Pipeline</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-6">
              {statusCounts.map((s, idx) => (
                <div key={idx} className="bg-[#071322] p-3 rounded-xl border border-[#162C47] text-center">
                  <span className="text-[10px] text-[#9AA4B2] font-medium block truncate">{s.label}</span>
                  <span className="text-lg font-bold font-mono text-white mt-1 block" style={{ color: s.color }}>
                    {s.count}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Smart City Average SLA Card */}
          <div className="bg-[#081527] p-3.5 rounded-xl border border-[#1B314B] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-[#22C55E]/15 text-[#22C55E] flex items-center justify-center font-bold">
                ⚡
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">Average Municipal Resolution SLA</h4>
                <p className="text-[11px] text-[#9AA4B2]">Fastest response on Critical hazards: 4.2 hours</p>
              </div>
            </div>
            <span className="text-xs font-mono font-bold text-[#22C55E] bg-[#22C55E]/10 px-2 py-1 rounded-lg">
              98.2% on-time
            </span>
          </div>

        </div>

      </div>

      {/* Recent Reports List */}
      <div className="bg-[#0B1728] rounded-2xl border border-[#162A42] shadow-lg overflow-hidden">
        
        <div className="p-5 border-b border-[#162A42] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-[#00BFFF]" />
            <h3 className="text-sm font-bold text-white">
              {t.recentReports}
            </h3>
          </div>
          <button
            onClick={() => setActiveTab('myReports')}
            className="text-xs font-semibold text-[#38BDF8] hover:text-white flex items-center gap-1 transition-colors"
          >
            <span>{t.myReports}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="divide-y divide-[#122238]">
          {reports.slice(0, 5).map((rep) => {
            const currentStage = rep.timeline[rep.timeline.length - 1]?.stage || 'Submitted';
            return (
              <div 
                key={rep.id}
                className="p-4 sm:p-5 hover:bg-[#0E1F36]/60 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                
                <div className="flex items-start gap-3.5">
                  {/* Thumbnail */}
                  <div className="w-14 h-14 rounded-xl overflow-hidden border border-[#1A2E46] bg-[#06111F] flex-shrink-0 flex items-center justify-center">
                    {rep.imageUrl ? (
                      <img src={rep.imageUrl} alt={rep.title} className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-xs text-[#64748B]">No photo</span>
                    )}
                  </div>

                  {/* Info */}
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-xs font-bold text-[#00BFFF]">
                        {rep.id}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.2 rounded-full border ${getPriorityBadge(rep.priority)}`}>
                        {rep.priority}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.2 rounded-full border ${getStatusBadge(currentStage)}`}>
                        {currentStage}
                      </span>
                    </div>

                    <h4 className="text-xs sm:text-sm font-bold text-white mt-1">
                      {rep.title}
                    </h4>

                    <div className="flex items-center gap-3 text-[11px] text-[#9AA4B2] mt-1 flex-wrap">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-[#38BDF8]" />
                        {rep.location.address}
                      </span>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-[#64748B]" />
                        {new Date(rep.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Right: ImpactScore + View ProofPath Button */}
                <div className="flex items-center justify-between md:justify-end gap-4 pl-17 md:pl-0">
                  <div className="text-left md:text-right">
                    <span className="text-[10px] text-[#9AA4B2] uppercase font-bold block">ImpactScore</span>
                    <span className="text-sm font-black text-white font-mono">
                      {rep.impactScore} <span className="text-[10px] text-[#64748B]">/100</span>
                    </span>
                  </div>

                  <button
                    onClick={() => setSelectedReportForProofPath(rep)}
                    className="px-3.5 py-1.5 rounded-xl bg-[#00BFFF]/15 hover:bg-[#00BFFF]/25 text-[#38BDF8] border border-[#00BFFF]/30 text-xs font-bold flex items-center gap-1.5 transition-colors"
                  >
                    <span>{t.viewDetails}</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>

              </div>
            );
          })}
        </div>

      </div>

    </div>
  );
};
