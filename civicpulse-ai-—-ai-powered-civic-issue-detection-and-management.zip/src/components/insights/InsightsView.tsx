import React, { useState } from 'react';
import { 
  BarChart3, 
  MapPin, 
  AlertTriangle, 
  TrendingUp, 
  Layers, 
  Clock, 
  CheckCircle2, 
  Sparkles, 
  Activity,
  ShieldAlert,
  ArrowRight
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { translations } from '../../utils/translations';
import { CivicReport, PriorityLevel } from '../../types';

export const InsightsView: React.FC = () => {
  const { reports, language, setSelectedReportForProofPath } = useApp();
  const t = translations[language];

  const [activePin, setActivePin] = useState<CivicReport | null>(null);

  // Hotspots: group by neighborhood or sector
  const sectorGroups: Record<string, CivicReport[]> = {};
  reports.forEach((rep) => {
    const sec = rep.location.neighborhood || 'Metro Sector 4';
    if (!sectorGroups[sec]) sectorGroups[sec] = [];
    sectorGroups[sec].push(rep);
  });

  const highPriorityQueue = reports.filter(
    (r) => ['High', 'Critical'].includes(r.priority) && r.timeline[r.timeline.length - 1]?.stage !== 'Resolved'
  );

  return (
    <div className="max-w-7xl mx-auto py-6 px-4 lg:px-8 space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-[#00BFFF]/15 text-[#38BDF8] border border-[#00BFFF]/30 font-bold">
              CITY TELEMETRY & SPATIAL ANALYTICS
            </span>
          </div>
          <h1 className="text-2xl font-black text-white">
            CivicPulse Insights & Hotspot Matrix
          </h1>
          <p className="text-xs text-[#9AA4B2] mt-1">
            Real-time hazard clustering, geographic incident density, and municipal response velocity.
          </p>
        </div>

        <div className="px-3 py-1.5 rounded-xl bg-[#0B1728] border border-[#162C47] text-xs font-mono text-[#38BDF8] flex items-center gap-2">
          <Activity className="w-3.5 h-3.5 text-[#00BFFF] animate-pulse" />
          <span>Active Nodes: {reports.length}</span>
        </div>
      </div>

      {/* Interactive Smart-City Hotspot Map Grid */}
      <div className="bg-[#0B1728] rounded-3xl border border-[#162A42] p-5 shadow-2xl relative overflow-hidden">
        
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#00BFFF]" />
              Smart-City Geographic Incident Matrix
            </h3>
            <p className="text-[11px] text-[#9AA4B2] mt-0.5">
              Click any glowing sector pin to inspect incident telemetry and ImpactScore.
            </p>
          </div>

          <div className="flex items-center gap-3 text-[11px]">
            <span className="flex items-center gap-1.5 text-[#EF4444] font-bold">
              <span className="w-2.5 h-2.5 rounded-full bg-[#EF4444] animate-ping" />
              Critical
            </span>
            <span className="flex items-center gap-1.5 text-[#F59E0B] font-bold">
              <span className="w-2.5 h-2.5 rounded-full bg-[#F59E0B]" />
              High
            </span>
            <span className="flex items-center gap-1.5 text-[#38BDF8] font-bold">
              <span className="w-2.5 h-2.5 rounded-full bg-[#38BDF8]" />
              Medium/Low
            </span>
          </div>
        </div>

        {/* SVG Smart City Grid Map */}
        <div className="relative w-full h-80 sm:h-96 rounded-2xl bg-[#06111F] border border-[#1A2E46] overflow-hidden flex items-center justify-center">
          
          {/* Subtle City Streets Vector Layer */}
          <svg className="absolute inset-0 w-full h-full opacity-40 pointer-events-none" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="city-block" width="80" height="80" patternUnits="userSpaceOnUse">
                <rect width="76" height="76" fill="#091424" rx="4" />
                <path d="M78 0 L78 80 M0 78 L80 78" stroke="#162E4C" stroke-width="2" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#city-block)" />
            {/* Main Arterial Road Highways */}
            <path d="M 0 160 Q 300 120 700 240 T 1200 180" stroke="#00BFFF" stroke-width="4" stroke-opacity="0.3" fill="none" />
            <path d="M 350 0 L 350 400" stroke="#00BFFF" stroke-width="3" stroke-opacity="0.25" fill="none" />
            <path d="M 680 0 L 680 400" stroke="#A855F7" stroke-width="3" stroke-opacity="0.25" fill="none" />
          </svg>

          {/* Interactive Report Pins placed on the city grid */}
          <div className="absolute inset-0 p-8 flex items-center justify-around pointer-events-auto">
            {reports.map((rep, idx) => {
              const isCrit = rep.priority === 'Critical';
              const isHigh = rep.priority === 'High';
              const pinColor = isCrit ? '#EF4444' : isHigh ? '#F59E0B' : '#00BFFF';

              // Scatter positions slightly based on index
              const topPos = 20 + ((idx * 27) % 65);
              const leftPos = 12 + ((idx * 33) % 75);

              return (
                <div
                  key={rep.id}
                  style={{ top: `${topPos}%`, left: `${leftPos}%` }}
                  onClick={() => setActivePin(rep)}
                  className="absolute cursor-pointer group transform -translate-x-1/2 -translate-y-1/2"
                >
                  <div className="relative flex items-center justify-center">
                    {/* Glowing pulse ring */}
                    <div 
                      className="absolute w-8 h-8 rounded-full opacity-50 animate-ping"
                      style={{ backgroundColor: pinColor }}
                    />
                    {/* Pin button */}
                    <div 
                      className="w-7 h-7 rounded-full flex items-center justify-center border-2 border-[#06111F] shadow-lg text-white text-[10px] font-bold group-hover:scale-125 transition-transform"
                      style={{ backgroundColor: pinColor }}
                    >
                      <MapPin className="w-3.5 h-3.5" />
                    </div>
                  </div>

                  {/* Tooltip on hover */}
                  <div className="absolute left-1/2 -translate-x-1/2 bottom-8 hidden group-hover:flex flex-col items-center z-30 pointer-events-none w-48">
                    <div className="bg-[#0A1728] border border-[#1E3A5F] px-2.5 py-1.5 rounded-xl shadow-2xl text-[10px] text-center w-full">
                      <p className="font-mono text-[#00BFFF] font-bold">{rep.id}</p>
                      <p className="text-white font-bold truncate">{rep.title}</p>
                      <p className="text-[#9AA4B2] text-[9px] mt-0.5 font-mono">ImpactScore: {rep.impactScore}</p>
                    </div>
                    <div className="w-2 h-2 bg-[#0A1728] border-r border-b border-[#1E3A5F] rotate-45 -mt-1" />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Active Pin Overlay Drawer */}
          {activePin && (
            <div className="absolute bottom-4 left-4 right-4 sm:left-auto sm:right-4 sm:w-96 bg-[#0A1728]/95 backdrop-blur-md border border-[#00BFFF]/50 rounded-2xl p-4 shadow-2xl z-40">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-mono text-xs font-bold text-[#00BFFF]">{activePin.id}</span>
                    <span className="text-[10px] font-bold px-2 py-0.2 rounded-full bg-[#EF4444]/20 text-[#EF4444]">
                      {activePin.priority}
                    </span>
                  </div>
                  <h4 className="text-xs font-bold text-white mt-1 line-clamp-1">{activePin.title}</h4>
                </div>
                <button
                  onClick={() => setActivePin(null)}
                  className="text-[#9AA4B2] hover:text-white text-xs font-bold p-1"
                >
                  ✕
                </button>
              </div>

              <p className="text-[11px] text-[#9AA4B2] mt-1.5 line-clamp-2">
                {activePin.description}
              </p>

              <div className="mt-3 pt-2 border-t border-[#162A42] flex items-center justify-between">
                <span className="text-[11px] text-[#38BDF8] font-mono">
                  ImpactScore: {activePin.impactScore}/100
                </span>
                <button
                  onClick={() => setSelectedReportForProofPath(activePin)}
                  className="text-xs font-bold text-[#00BFFF] hover:underline flex items-center gap-1"
                >
                  ProofPath Trail <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          )}

        </div>

      </div>

      {/* Lower Row: Unresolved High Priority Queue & Neighborhood Density */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Unresolved High Priority Queue */}
        <div className="bg-[#0B1728] rounded-2xl border border-[#EF4444]/30 p-5 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-[#EF4444]" />
              Active High & Critical Urgency Queue
            </h3>
            <span className="text-[11px] font-mono font-bold text-[#EF4444] bg-[#EF4444]/15 px-2 py-0.5 rounded-full">
              {highPriorityQueue.length} Active SLA Alerts
            </span>
          </div>

          <div className="space-y-2.5">
            {highPriorityQueue.map((rep) => (
              <div 
                key={rep.id}
                onClick={() => setSelectedReportForProofPath(rep)}
                className="p-3 rounded-xl bg-[#071322] border border-[#162C47] hover:border-[#EF4444]/50 cursor-pointer transition-all flex items-center justify-between gap-3 group"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[11px] font-bold text-[#00BFFF]">{rep.id}</span>
                    <span className="text-[10px] font-bold text-[#EF4444]">{rep.priority}</span>
                  </div>
                  <h4 className="text-xs font-bold text-white group-hover:text-[#38BDF8] transition-colors mt-0.5">
                    {rep.title}
                  </h4>
                  <p className="text-[10px] text-[#9AA4B2] mt-0.5 truncate max-w-xs">{rep.location.address}</p>
                </div>

                <div className="text-right">
                  <span className="text-[10px] text-[#64748B] block font-semibold">Impact</span>
                  <span className="text-xs font-bold font-mono text-[#EF4444]">{rep.impactScore} pts</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Geographic Sector Clustering */}
        <div className="bg-[#0B1728] rounded-2xl border border-[#162A42] p-5 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-[#00BFFF]" />
              District Clustering & Volume
            </h3>
            <span className="text-[11px] text-[#64748B]">Spatial Aggregation</span>
          </div>

          <div className="space-y-3">
            {Object.entries(sectorGroups).map(([sector, groupReports]) => {
              const critCount = groupReports.filter(r => r.priority === 'Critical').length;
              return (
                <div key={sector} className="p-3 rounded-xl bg-[#071322] border border-[#162C47]">
                  <div className="flex items-center justify-between mb-1 text-xs">
                    <span className="font-bold text-white flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-[#38BDF8]" />
                      {sector}
                    </span>
                    <span className="font-mono text-[#00BFFF] font-bold">
                      {groupReports.length} incidents
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-[10px] text-[#9AA4B2] mt-1">
                    <span>Resolved: {groupReports.filter(r => r.timeline[r.timeline.length - 1]?.stage === 'Resolved').length}</span>
                    <span>•</span>
                    <span className="text-[#EF4444]">Critical alerts: {critCount}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>

    </div>
  );
};
