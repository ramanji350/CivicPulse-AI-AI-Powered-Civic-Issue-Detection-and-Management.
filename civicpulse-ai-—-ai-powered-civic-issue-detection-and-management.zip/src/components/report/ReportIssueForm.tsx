import React, { useState } from 'react';
import { 
  Upload, 
  MapPin, 
  Sparkles, 
  AlertTriangle, 
  CheckCircle2, 
  Camera, 
  Navigation, 
  Layers, 
  Info, 
  ArrowRight,
  Volume2,
  FileCheck
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { translations } from '../../utils/translations';
import { IssueCategory, PriorityLevel, CivicReport } from '../../types';
import { ISSUE_IMAGES } from '../../data/sampleReports';
import { analyzeCivicIssue, AIAnalysisResult } from '../../utils/aiAnalyzer';

export const ReportIssueForm: React.FC = () => {
  const { 
    language, 
    reports, 
    addReport, 
    setSelectedReportForProofPath,
    setActiveTab 
  } = useApp();
  const t = translations[language];

  // Form State
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<IssueCategory>('pothole');
  const [locationAddress, setLocationAddress] = useState('');
  const [selectedImage, setSelectedImage] = useState<string>(ISSUE_IMAGES.potholeBefore);
  const [gpsLoading, setGpsLoading] = useState(false);

  // AI Analysis State
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AIAnalysisResult | null>(null);
  const [confirmedPriority, setConfirmedPriority] = useState<PriorityLevel>('High');

  // Submission State
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedReport, setSubmittedReport] = useState<CivicReport | null>(null);

  // Photo presets for quick testing
  const PRESET_PHOTOS = [
    { label: 'Pothole Crater', category: 'pothole' as IssueCategory, url: ISSUE_IMAGES.potholeBefore, title: 'Deep Crater on 5th Avenue' },
    { label: 'Overflowing Waste', category: 'garbage' as IssueCategory, url: ISSUE_IMAGES.garbageBefore, title: 'Spilled Trash Dumpster' },
    { label: 'Dark Streetlight', category: 'streetlight' as IssueCategory, url: ISSUE_IMAGES.streetlightBefore, title: 'Blackout Street Lamp' },
    { label: 'Fractured Walkway', category: 'footpath' as IssueCategory, url: ISSUE_IMAGES.footpathBefore, title: 'Uprooted Pedestrian Slabs' },
    { label: 'Water Main Pipe', category: 'water_leak' as IssueCategory, url: ISSUE_IMAGES.waterLeakBefore, title: 'Pressurized Pipe Rupture' },
  ];

  const handleSelectPreset = (preset: typeof PRESET_PHOTOS[0]) => {
    setSelectedImage(preset.url);
    setCategory(preset.category);
    if (!title) setTitle(preset.title);
    if (!description) {
      if (preset.category === 'pothole') {
        setDescription('Deep crater on the main lane causing vehicles to swerve abruptly near bus stop.');
      } else if (preset.category === 'garbage') {
        setDescription('Overflowing dumpster spilling refuse across the public sidewalk. Stray animals feeding.');
      } else if (preset.category === 'streetlight') {
        setDescription('Streetlight completely dark creating a blackout hazard zone on the pedestrian avenue.');
      } else if (preset.category === 'footpath') {
        setDescription('Fractured tripping hazard concrete slabs outside school pedestrian gate.');
      } else if (preset.category === 'water_leak') {
        setDescription('Underground water main leak flooding the roadway and causing pavement erosion.');
      }
    }
    if (!locationAddress) {
      setLocationAddress('842 Metro Boulevard, Sector 4');
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setSelectedImage(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFetchGpsLocation = () => {
    if (!navigator.geolocation) {
      setLocationAddress('GPS unavailable; using default: Sector 5 Central Park Ave');
      return;
    }
    setGpsLoading(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setGpsLoading(false);
        const lat = pos.coords.latitude.toFixed(4);
        const lng = pos.coords.longitude.toFixed(4);
        setLocationAddress(`GPS Coordinates: ${lat}° N, ${lng}° W (Civic Sector 3, West Zone)`);
      },
      () => {
        setGpsLoading(false);
        // Fallback realistic smart-city street
        setLocationAddress('Civic District 4, Metro Arterial Corridor (GPS simulated)');
      },
      { timeout: 5000 }
    );
  };

  const handleRunAnalysis = async () => {
    if (!description && !title) {
      setDescription('Pavement crater on active traffic roadway presenting collision liability.');
    }
    if (!locationAddress) {
      setLocationAddress('3rd Avenue & Market Lane, Sector 2');
    }

    setIsAnalyzing(true);
    const result = await analyzeCivicIssue(
      description || title,
      category,
      locationAddress || 'Central Boulevard',
      reports
    );
    setIsAnalyzing(false);
    setAnalysisResult(result);
    setCategory(result.detectedCategory);
    setConfirmedPriority(result.suggestedPriority);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    setTimeout(() => {
      setIsSubmitting(false);
      const newRep = addReport({
        title: title || `${t.categories[category]} Hazard`,
        description: description || 'Civic safety incident detected.',
        category,
        priority: confirmedPriority,
        impactScore: analysisResult ? analysisResult.impactScore : 78,
        impactReasons: analysisResult ? analysisResult.reasons : ['Prioritized by Municipal Safety Criteria'],
        location: {
          address: locationAddress || 'Civic Center Boulevard',
          neighborhood: 'Metropolitan District',
        },
        imageUrl: selectedImage,
        duplicateOf: analysisResult?.duplicateMatch?.reportId,
      });

      setSubmittedReport(newRep);
    }, 700);
  };

  // Confirmation screen view once submitted
  if (submittedReport) {
    return (
      <div className="max-w-3xl mx-auto py-8 px-4">
        <div className="bg-[#0B1728] border border-[#22C55E]/40 rounded-3xl p-8 text-center shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#22C55E]/10 rounded-full blur-3xl pointer-events-none" />
          
          <div className="w-16 h-16 rounded-3xl bg-[#22C55E]/20 border border-[#22C55E]/50 flex items-center justify-center mx-auto mb-4 text-[#22C55E] shadow-lg shadow-[#22C55E]/20">
            <CheckCircle2 className="w-8 h-8" />
          </div>

          <span className="text-[11px] font-mono font-bold px-3 py-1 rounded-full bg-[#00BFFF]/15 text-[#38BDF8] border border-[#00BFFF]/30">
            REPORT REGISTERED: {submittedReport.id}
          </span>

          <h2 className="text-2xl font-bold text-white mt-3">
            {t.reportSuccessTitle}
          </h2>
          <p className="text-xs sm:text-sm text-[#9AA4B2] mt-2 max-w-lg mx-auto leading-relaxed">
            {t.reportSuccessDesc}
          </p>

          {/* Quick Summary Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 my-6 max-w-2xl mx-auto text-left">
            <div className="bg-[#081424] p-3 rounded-xl border border-[#162C47]">
              <span className="text-[10px] text-[#9AA4B2] uppercase font-bold">Category</span>
              <p className="text-xs font-bold text-white mt-1 capitalize">{t.categories[submittedReport.category]}</p>
            </div>
            <div className="bg-[#081424] p-3 rounded-xl border border-[#162C47]">
              <span className="text-[10px] text-[#9AA4B2] uppercase font-bold">ImpactScore</span>
              <p className="text-xs font-bold text-[#00BFFF] mt-1 font-mono">{submittedReport.impactScore} / 100</p>
            </div>
            <div className="bg-[#081424] p-3 rounded-xl border border-[#162C47]">
              <span className="text-[10px] text-[#9AA4B2] uppercase font-bold">Priority</span>
              <p className="text-xs font-bold text-[#F59E0B] mt-1">{submittedReport.priority}</p>
            </div>
            <div className="bg-[#081424] p-3 rounded-xl border border-[#162C47]">
              <span className="text-[10px] text-[#9AA4B2] uppercase font-bold">Initial Status</span>
              <p className="text-xs font-bold text-[#22C55E] mt-1">Submitted</p>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4 border-t border-[#162A42]">
            <button
              onClick={() => setSelectedReportForProofPath(submittedReport)}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#00BFFF] to-[#38BDF8] text-[#06111F] font-bold text-xs shadow-lg shadow-[#00BFFF]/20 flex items-center justify-center gap-2 hover:opacity-95 transition-all"
            >
              <FileCheck className="w-4 h-4" />
              View in ProofPath Timeline
            </button>

            <button
              onClick={() => {
                setSubmittedReport(null);
                setAnalysisResult(null);
                setTitle('');
                setDescription('');
                setLocationAddress('');
              }}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-[#101F33] hover:bg-[#15273F] text-xs font-bold text-white border border-[#1E3A5F] transition-colors"
            >
              Report Another Issue
            </button>

            <button
              onClick={() => setActiveTab('dashboard')}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl text-xs font-bold text-[#9AA4B2] hover:text-white transition-colors"
            >
              Return to Dashboard
            </button>
          </div>

        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto py-6 px-4">
      
      {/* Title Header */}
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs font-bold font-mono px-2 py-0.5 rounded-full bg-[#00BFFF]/15 text-[#38BDF8] border border-[#00BFFF]/30">
            CITIZEN REPORTING WORKFLOW
          </span>
        </div>
        <h1 className="text-2xl font-black text-white">
          {t.reportCivicIssue}
        </h1>
        <p className="text-xs text-[#9AA4B2] mt-1">
          Submit photo evidence, run AI safety & impact analysis, and track municipal resolution.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        
        {/* SECTION 1: Image Upload & Presets */}
        <div className="bg-[#0B1728] border border-[#1A2E46] rounded-2xl p-5 shadow-lg">
          <label className="block text-xs font-bold text-white mb-2 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Camera className="w-4 h-4 text-[#00BFFF]" />
              {t.uploadImage}
            </span>
            <span className="text-[11px] text-[#64748B]">
              PNG, JPG, SVG or Pick Sample Preset
            </span>
          </label>

          {/* Quick presets row */}
          <div className="mb-4">
            <span className="text-[11px] font-semibold text-[#9AA4B2] block mb-2">
              ⚡ Quick Sample Presets (Click to test instantly):
            </span>
            <div className="flex flex-wrap gap-2">
              {PRESET_PHOTOS.map((p, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => handleSelectPreset(p)}
                  className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                    selectedImage === p.url
                      ? 'bg-[#00BFFF]/20 text-[#38BDF8] border-[#00BFFF] shadow-sm'
                      : 'bg-[#081424] text-[#9AA4B2] border-[#162C47] hover:bg-[#101F33] hover:text-white'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Image Preview & Upload Container */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
            <div className="h-44 rounded-xl overflow-hidden border border-[#162C47] bg-[#06111F] relative flex items-center justify-center">
              {selectedImage ? (
                <img
                  src={selectedImage}
                  alt="Incident Preview"
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="text-center p-4">
                  <Camera className="w-8 h-8 text-[#475569] mx-auto mb-1" />
                  <span className="text-xs text-[#64748B]">No photo selected</span>
                </div>
              )}
            </div>

            <div className="space-y-3">
              <label className="flex flex-col items-center justify-center h-44 rounded-xl border-2 border-dashed border-[#1E3A5F] hover:border-[#00BFFF] bg-[#081424] hover:bg-[#0E1F36] transition-all cursor-pointer p-4 text-center">
                <Upload className="w-6 h-6 text-[#00BFFF] mb-2" />
                <span className="text-xs font-bold text-white">Upload from Device</span>
                <span className="text-[11px] text-[#9AA4B2] mt-0.5">Take photo or browse files</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>
        </div>

        {/* SECTION 2: Location & Problem Description */}
        <div className="bg-[#0B1728] border border-[#1A2E46] rounded-2xl p-5 shadow-lg space-y-4">
          
          {/* Location with GPS */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-white flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-[#00BFFF]" />
                {t.locationAddress}
              </label>
              <button
                type="button"
                onClick={handleFetchGpsLocation}
                disabled={gpsLoading}
                className="text-[11px] font-semibold text-[#00BFFF] hover:text-[#38BDF8] flex items-center gap-1 transition-colors"
              >
                <Navigation className={`w-3 h-3 ${gpsLoading ? 'animate-spin' : ''}`} />
                {gpsLoading ? 'Detecting GPS...' : t.useCurrentGps}
              </button>
            </div>
            <input
              type="text"
              required
              value={locationAddress}
              onChange={(e) => setLocationAddress(e.target.value)}
              placeholder="e.g. 5th Avenue & Metro Transit Corridor, Sector 4"
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#071322] border border-[#1A2E46] text-white text-xs placeholder-[#4B5E77] focus:outline-none focus:border-[#00BFFF] focus:ring-1 focus:ring-[#00BFFF]"
            />
          </div>

          {/* Incident Category */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-white mb-1.5">
                Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as IssueCategory)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#071322] border border-[#1A2E46] text-white text-xs focus:outline-none focus:border-[#00BFFF]"
              >
                <option value="pothole">{t.categories.pothole}</option>
                <option value="garbage">{t.categories.garbage}</option>
                <option value="streetlight">{t.categories.streetlight}</option>
                <option value="footpath">{t.categories.footpath}</option>
                <option value="water_leak">{t.categories.water_leak}</option>
                <option value="traffic_signal">{t.categories.traffic_signal}</option>
                <option value="other">{t.categories.other}</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-white mb-1.5">
                Incident Summary / Title
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Deep Asphalt Crater near Bus Stop"
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#071322] border border-[#1A2E46] text-white text-xs placeholder-[#4B5E77] focus:outline-none focus:border-[#00BFFF]"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold text-white mb-1.5">
              Detailed Description & Hazards
            </label>
            <textarea
              rows={3}
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder={t.descriptionPlaceholder}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#071322] border border-[#1A2E46] text-white text-xs placeholder-[#4B5E77] focus:outline-none focus:border-[#00BFFF] leading-relaxed"
            />
          </div>

          {/* ANALYZE ISSUE BUTTON */}
          <div className="pt-2">
            <button
              type="button"
              onClick={handleRunAnalysis}
              disabled={isAnalyzing}
              className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#0B213F] via-[#0E2A52] to-[#123668] hover:border-[#00BFFF] border border-[#00BFFF]/40 text-[#38BDF8] font-bold text-xs shadow-md flex items-center justify-center gap-2 group transition-all"
            >
              <Sparkles className={`w-4 h-4 text-[#00BFFF] ${isAnalyzing ? 'animate-spin' : 'group-hover:scale-110'}`} />
              <span>{isAnalyzing ? t.analyzingWithAi : t.analyzeIssue}</span>
            </button>
          </div>

        </div>

        {/* SECTION 3: AI ANALYSIS RESULTS (CivicCluster & ImpactScore) */}
        {analysisResult && (
          <div className="bg-[#0B1728] border-2 border-[#00BFFF]/40 rounded-2xl p-5 shadow-2xl relative overflow-hidden animate-in fade-in duration-300">
            <div className="absolute top-0 right-0 w-48 h-48 bg-[#00BFFF]/10 rounded-full blur-2xl pointer-events-none" />

            <div className="flex items-center justify-between pb-3 border-b border-[#162A42]">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#00BFFF] animate-ping" />
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#00BFFF]" />
                  {t.impactScoreTitle}
                </h3>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#00BFFF]/15 text-[#38BDF8] border border-[#00BFFF]/30">
                {analysisResult.analysisMode} ({analysisResult.confidence}% confidence)
              </span>
            </div>

            {/* CivicCluster Duplicate Detection Alert */}
            {analysisResult.duplicateMatch && (
              <div className="my-3 p-3 rounded-xl bg-[#F59E0B]/15 border border-[#F59E0B]/40 text-[#F59E0B] text-xs flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold block">
                    CivicCluster: Potential Duplicate Incident Detected!
                  </span>
                  <p className="text-[11px] text-[#CBD5E1] mt-0.5">
                    Matches existing active report <span className="font-mono text-white font-bold">{analysisResult.duplicateMatch.reportId}</span> ("{analysisResult.duplicateMatch.title}"). {analysisResult.duplicateMatch.distanceNote}. Your submission will be linked to prevent redundant municipal dispatch.
                  </p>
                </div>
              </div>
            )}

            {/* ImpactScore Gauge & Priority Recommendation */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 my-4">
              
              <div className="bg-[#081424] p-3.5 rounded-xl border border-[#162C47]">
                <span className="text-[11px] text-[#9AA4B2] font-semibold">Calculated ImpactScore</span>
                <div className="flex items-baseline gap-2 mt-1">
                  <span className="text-3xl font-black text-white font-mono">
                    {analysisResult.impactScore}
                  </span>
                  <span className="text-xs text-[#9AA4B2]">/ 100</span>
                </div>
                <div className="w-full bg-[#101F33] h-2 rounded-full mt-2 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-[#00BFFF] via-[#F59E0B] to-[#EF4444]"
                    style={{ width: `${analysisResult.impactScore}%` }}
                  />
                </div>
              </div>

              <div className="bg-[#081424] p-3.5 rounded-xl border border-[#162C47]">
                <span className="text-[11px] text-[#9AA4B2] font-semibold">Suggested Priority</span>
                <div className="mt-2">
                  <span className={`text-xs font-black px-2.5 py-1 rounded-full border ${
                    confirmedPriority === 'Critical' ? 'bg-[#EF4444]/20 text-[#EF4444] border-[#EF4444]' :
                    confirmedPriority === 'High' ? 'bg-[#F59E0B]/20 text-[#F59E0B] border-[#F59E0B]' :
                    confirmedPriority === 'Medium' ? 'bg-[#38BDF8]/20 text-[#38BDF8] border-[#38BDF8]' :
                    'bg-[#22C55E]/20 text-[#22C55E] border-[#22C55E]'
                  }`}>
                    {confirmedPriority} Priority
                  </span>
                </div>
                <span className="text-[10px] text-[#64748B] block mt-2">
                  Based on safety hazard & traffic liability rules
                </span>
              </div>

              <div className="bg-[#081424] p-3.5 rounded-xl border border-[#162C47]">
                <span className="text-[11px] text-[#9AA4B2] font-semibold">Priority Override (Staff / Citizen)</span>
                <select
                  value={confirmedPriority}
                  onChange={(e) => setConfirmedPriority(e.target.value as PriorityLevel)}
                  className="w-full mt-2 px-2.5 py-1.5 rounded-lg bg-[#0E1F36] border border-[#1E3A5F] text-xs text-white"
                >
                  <option value="Low">Low Priority</option>
                  <option value="Medium">Medium Priority</option>
                  <option value="High">High Priority</option>
                  <option value="Critical">Critical Priority</option>
                </select>
              </div>

            </div>

            {/* Reasons Breakdown */}
            <div className="pt-2">
              <span className="text-[11px] font-bold text-[#CBD5E1] block mb-1">
                Transparent Impact Scoring Reasons:
              </span>
              <ul className="space-y-1">
                {analysisResult.reasons.map((r, i) => (
                  <li key={i} className="text-xs text-[#9AA4B2] flex items-start gap-2">
                    <span className="text-[#00BFFF] font-bold mt-0.5">•</span>
                    <span>{r}</span>
                  </li>
                ))}
              </ul>
            </div>

          </div>
        )}

        {/* SUBMIT BUTTON */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3 px-6 rounded-2xl bg-gradient-to-r from-[#00BFFF] to-[#38BDF8] text-[#06111F] font-bold text-sm shadow-xl shadow-[#00BFFF]/20 hover:opacity-95 active:scale-[0.99] transition-all flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <span className="inline-block w-4 h-4 border-2 border-[#06111F] border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <span>{t.submitReport}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>

      </form>
    </div>
  );
};
