import React from 'react';
import { 
  X, 
  CheckCircle2, 
  Clock, 
  MapPin, 
  AlertTriangle, 
  ShieldCheck, 
  Layers, 
  Calendar, 
  User, 
  ExternalLink,
  Sparkles
} from 'lucide-react';
import { CivicReport } from '../../types';
import { useApp } from '../../context/AppContext';
import { translations } from '../../utils/translations';

interface ProofPathModalProps {
  report: CivicReport;
  onClose: () => void;
}

export const ProofPathModal: React.FC<ProofPathModalProps> = ({ report, onClose }) => {
  const { language } = useApp();
  const t = translations[language];

  const getPriorityBadgeClass = (priority: string) => {
    switch (priority) {
      case 'Critical':
        return 'bg-[#EF4444]/20 text-[#EF4444] border-[#EF4444]/40';
      case 'High':
        return 'bg-[#F59E0B]/20 text-[#F59E0B] border-[#F59E0B]/40';
      case 'Medium':
        return 'bg-[#38BDF8]/20 text-[#38BDF8] border-[#38BDF8]/40';
      default:
        return 'bg-[#22C55E]/20 text-[#22C55E] border-[#22C55E]/40';
    }
  };

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'Resolved':
        return 'bg-[#22C55E]/20 text-[#22C55E] border-[#22C55E]/40';
      case 'In Progress':
        return 'bg-[#00BFFF]/20 text-[#38BDF8] border-[#00BFFF]/40';
      case 'Assigned':
        return 'bg-[#A855F7]/20 text-[#C084FC] border-[#A855F7]/40';
      case 'Under Review':
        return 'bg-[#F59E0B]/20 text-[#F59E0B] border-[#F59E0B]/40';
      default:
        return 'bg-[#9AA4B2]/20 text-[#CBD5E1] border-[#9AA4B2]/40';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-4xl max-h-[90vh] bg-[#0A1728] border border-[#1A2E46] rounded-3xl shadow-2xl overflow-hidden flex flex-col">
        
        {/* Modal Header */}
        <div className="px-6 py-4 bg-[#0D1C30] border-b border-[#1A2E46] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-[#00BFFF]/15 border border-[#00BFFF]/30 text-[#00BFFF]">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs font-bold text-[#00BFFF]">
                  {report.id}
                </span>
                <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full border ${getPriorityBadgeClass(report.priority)}`}>
                  {report.priority} Priority
                </span>
                <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full border ${getStatusBadgeClass(report.timeline[report.timeline.length - 1]?.stage || 'Submitted')}`}>
                  {report.timeline[report.timeline.length - 1]?.stage || 'Submitted'}
                </span>
              </div>
              <h2 className="text-base sm:text-lg font-bold text-white mt-1">
                {report.title}
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-[#9AA4B2] hover:text-white rounded-xl hover:bg-[#15273F] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          
          {/* Key Details Row: Location, ImpactScore, Team */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-[#081424] p-3 rounded-2xl border border-[#162C47]">
              <span className="text-[11px] text-[#9AA4B2] flex items-center gap-1 font-semibold">
                <MapPin className="w-3.5 h-3.5 text-[#00BFFF]" />
                Incident Location
              </span>
              <p className="text-xs font-semibold text-white mt-1">
                {report.location.address}
              </p>
              {report.location.neighborhood && (
                <p className="text-[10px] text-[#38BDF8] mt-0.5">
                  Sector: {report.location.neighborhood}
                </p>
              )}
            </div>

            <div className="bg-[#081424] p-3 rounded-2xl border border-[#162C47]">
              <span className="text-[11px] text-[#9AA4B2] flex items-center gap-1 font-semibold">
                <Layers className="w-3.5 h-3.5 text-[#A855F7]" />
                ImpactScore Matrix
              </span>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-xl font-black text-white font-mono">
                  {report.impactScore}
                </span>
                <span className="text-xs text-[#9AA4B2]">/ 100</span>
                <div className="flex-1 bg-[#101F33] h-2 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-[#00BFFF] to-[#EF4444]"
                    style={{ width: `${report.impactScore}%` }}
                  />
                </div>
              </div>
            </div>

            <div className="bg-[#081424] p-3 rounded-2xl border border-[#162C47]">
              <span className="text-[11px] text-[#9AA4B2] flex items-center gap-1 font-semibold">
                <ShieldCheck className="w-3.5 h-3.5 text-[#22C55E]" />
                Assigned Maintenance Team
              </span>
              <p className="text-xs font-semibold text-white mt-1">
                {report.assignedTeam || 'Pending municipal dispatch'}
              </p>
            </div>
          </div>

          {/* Description & Impact Reasons */}
          <div className="bg-[#081424] p-4 rounded-2xl border border-[#162C47] space-y-3">
            <div>
              <h4 className="text-xs font-bold text-[#CBD5E1] uppercase tracking-wider mb-1">
                Citizen Incident Description
              </h4>
              <p className="text-xs text-[#9AA4B2] leading-relaxed">
                {report.description}
              </p>
            </div>

            {report.impactReasons && report.impactReasons.length > 0 && (
              <div className="pt-3 border-t border-[#122238]">
                <h5 className="text-[11px] font-bold text-[#00BFFF] mb-1.5 flex items-center gap-1">
                  <Sparkles className="w-3 h-3" />
                  AI ImpactScore Factor Evaluation:
                </h5>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                  {report.impactReasons.map((reason, i) => (
                    <li key={i} className="text-[11px] text-[#CBD5E1] flex items-start gap-1.5">
                      <span className="text-[#00BFFF] mt-0.5">•</span>
                      <span>{reason}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Before & After Evidence Section */}
          <div className="bg-[#081424] p-4 rounded-2xl border border-[#162C47]">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-[#22C55E]" />
                {t.beforeAfterEvidence}
              </span>
              {report.resolutionImageUrl && (
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#22C55E]/20 text-[#22C55E] border border-[#22C55E]/40 font-bold">
                  VERIFIED RESOLUTION SIGN-OFF
                </span>
              )}
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              {/* Initial Incident Photo */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-[11px] font-semibold text-[#9AA4B2]">
                  <span>Before: Reported Hazard</span>
                  <span className="text-[10px] text-[#64748B]">Citizen Upload</span>
                </div>
                <div className="h-48 rounded-xl overflow-hidden border border-[#162C47] bg-[#050D18] flex items-center justify-center relative">
                  {report.imageUrl ? (
                    <img 
                      src={report.imageUrl} 
                      alt="Initial Civic Hazard" 
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="text-center text-xs text-[#64748B]">
                      No photo attached
                    </div>
                  )}
                </div>
              </div>

              {/* Resolved Photo */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-[11px] font-semibold text-[#9AA4B2]">
                  <span>After: Resolution Proof</span>
                  <span className="text-[10px] text-[#22C55E]">Municipal Verification</span>
                </div>
                <div className="h-48 rounded-xl overflow-hidden border border-[#162C47] bg-[#050D18] flex items-center justify-center relative">
                  {report.resolutionImageUrl ? (
                    <img 
                      src={report.resolutionImageUrl} 
                      alt="Verified Resolution" 
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="text-center p-4">
                      <Clock className="w-6 h-6 text-[#64748B] mx-auto mb-1.5" />
                      <p className="text-xs text-[#9AA4B2] font-semibold">
                        Awaiting Field Crew Resolution Evidence
                      </p>
                      <p className="text-[10px] text-[#64748B] mt-1">
                        Repair proof photo will be posted here once work is marked Resolved.
                      </p>
                    </div>
                  )}
                </div>
                {report.resolutionNotes && (
                  <p className="text-[11px] text-[#38BDF8] italic mt-1">
                    "{report.resolutionNotes}"
                  </p>
                )}
              </div>

            </div>
          </div>

          {/* ProofPath Resolution Timeline Trail */}
          <div className="bg-[#081424] p-4 rounded-2xl border border-[#162C47]">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-[#00BFFF]" />
              {t.proofPathTimeline}
            </h4>

            <div className="relative pl-6 space-y-6 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-[#162C47]">
              {report.timeline.map((evt, index) => {
                const isLatest = index === report.timeline.length - 1;
                return (
                  <div key={evt.id || index} className="relative group">
                    {/* Circle marker on timeline */}
                    <div 
                      className={`absolute -left-[27px] top-0.5 w-4 h-4 rounded-full border-2 transition-all ${
                        isLatest 
                          ? 'bg-[#00BFFF] border-[#06111F] ring-4 ring-[#00BFFF]/20 animate-pulse'
                          : 'bg-[#101F33] border-[#38BDF8]'
                      }`} 
                    />

                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs font-bold text-white">
                          {evt.title}
                        </span>
                        <span className={`text-[10px] px-2 py-0.2 rounded-full border font-semibold ${getStatusBadgeClass(evt.stage)}`}>
                          {evt.stage}
                        </span>
                        <span className="text-[10px] text-[#64748B] font-mono">
                          {new Date(evt.timestamp).toLocaleString()}
                        </span>
                      </div>

                      <p className="text-xs text-[#9AA4B2] mt-1">
                        {evt.description}
                      </p>
                      <p className="text-[10px] text-[#475569] mt-0.5">
                        Logged by: {evt.actor}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 bg-[#0D1C30] border-t border-[#1A2E46] flex items-center justify-between">
          <div className="text-[11px] text-[#64748B]">
            Report ID: <span className="text-white font-mono">{report.id}</span> • Public Ledger Sign-off
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-[#101F33] hover:bg-[#15273F] text-xs font-bold text-white border border-[#1E3A5F] transition-colors"
          >
            Close ProofPath
          </button>
        </div>

      </div>
    </div>
  );
};
