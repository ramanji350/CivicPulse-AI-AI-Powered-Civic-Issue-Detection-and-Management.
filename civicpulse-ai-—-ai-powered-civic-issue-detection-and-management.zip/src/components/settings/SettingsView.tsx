import React from 'react';
import { 
  Settings, 
  Volume2, 
  VolumeX, 
  Globe, 
  RotateCcw, 
  ShieldCheck, 
  Database, 
  CheckCircle2, 
  Cpu, 
  Layers
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { translations } from '../../utils/translations';
import { Language } from '../../types';
import { speak } from '../../utils/speech';

export const SettingsView: React.FC = () => {
  const { 
    language, 
    setLanguage, 
    voiceEnabled, 
    setVoiceEnabled, 
    resetDemoData, 
    reports 
  } = useApp();
  const t = translations[language];

  const languagesList: { code: Language; label: string; flag: string; native: string }[] = [
    { code: 'en', label: 'English', flag: '🇺🇸', native: 'English' },
    { code: 'es', label: 'Spanish', flag: '🇪🇸', native: 'Español' },
    { code: 'hi', label: 'Hindi', flag: '🇮🇳', native: 'हिन्दी' },
    { code: 'fr', label: 'French', flag: '🇫🇷', native: 'Français' },
    { code: 'de', label: 'German', flag: '🇩🇪', native: 'Deutsch' },
    { code: 'te', label: 'Telugu', flag: '🇮🇳', native: 'తెలుగు' },
  ];

  const handleTestVoiceAudio = () => {
    speak('Testing CivicPulse AI audio synthesizer. Voice alerts active.', language);
  };

  return (
    <div className="max-w-4xl mx-auto py-6 px-4 space-y-6">
      
      {/* Title */}
      <div>
        <h1 className="text-2xl font-black text-white">
          System Settings & Preferences
        </h1>
        <p className="text-xs text-[#9AA4B2] mt-1">
          Configure language localization, speech telemetry, and presentation demo storage.
        </p>
      </div>

      {/* Voice Alerts Card */}
      <div className="bg-[#0B1728] rounded-2xl border border-[#162A42] p-5 shadow-lg space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#00BFFF]/15 border border-[#00BFFF]/30 text-[#00BFFF] flex items-center justify-center">
              <Volume2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">
                Web Speech Synthesis & Voice Alerts
              </h3>
              <p className="text-xs text-[#9AA4B2]">
                Speaks spoken confirmations upon report submission and real-time status transitions.
              </p>
            </div>
          </div>

          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={voiceEnabled}
              onChange={(e) => setVoiceEnabled(e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-[#162A42] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#00BFFF]"></div>
          </label>
        </div>

        {voiceEnabled && (
          <div className="pt-2 border-t border-[#162A42] flex items-center justify-between">
            <span className="text-xs text-[#CBD5E1]">
              Voice alert status: <strong className="text-[#22C55E]">Active (Browser Web Speech API)</strong>
            </span>
            <button
              onClick={handleTestVoiceAudio}
              className="px-3 py-1.5 rounded-lg bg-[#00BFFF]/15 hover:bg-[#00BFFF]/25 text-[#38BDF8] border border-[#00BFFF]/30 text-xs font-bold transition-colors"
            >
              Test Voice Synthesizer
            </button>
          </div>
        )}
      </div>

      {/* Multi-Language Selection Card */}
      <div className="bg-[#0B1728] rounded-2xl border border-[#162A42] p-5 shadow-lg space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#A855F7]/15 border border-[#A855F7]/30 text-[#A855F7] flex items-center justify-center">
            <Globe className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">
              Application Language Localization
            </h3>
            <p className="text-xs text-[#9AA4B2]">
              Select your preferred language. All pages, workflows, and chatbot dialogues adapt instantly.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2">
          {languagesList.map((l) => (
            <button
              key={l.code}
              onClick={() => setLanguage(l.code)}
              className={`p-3 rounded-xl border text-left transition-all flex items-center justify-between ${
                language === l.code
                  ? 'bg-[#00BFFF]/20 border-[#00BFFF] text-white shadow-md'
                  : 'bg-[#071322] border-[#162C47] text-[#9AA4B2] hover:bg-[#101F33] hover:text-white'
              }`}
            >
              <div>
                <span className="text-base mr-2">{l.flag}</span>
                <span className="text-xs font-bold text-white">{l.native}</span>
                <p className="text-[10px] text-[#64748B] mt-0.5">{l.label}</p>
              </div>
              {language === l.code && <CheckCircle2 className="w-4 h-4 text-[#00BFFF]" />}
            </button>
          ))}
        </div>
      </div>

      {/* Reset Demo Data & Storage */}
      <div className="bg-[#0B1728] rounded-2xl border border-[#162A42] p-5 shadow-lg space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#F59E0B]/15 border border-[#F59E0B]/30 text-[#F59E0B] flex items-center justify-center">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">
                Demonstration Storage & Data Reset
              </h3>
              <p className="text-xs text-[#9AA4B2]">
                Restore pre-seeded smart-city incident records, verified ProofPath evidence, and notifications.
              </p>
            </div>
          </div>

          <button
            onClick={resetDemoData}
            className="px-4 py-2 rounded-xl bg-[#F59E0B]/15 hover:bg-[#F59E0B]/25 text-[#F59E0B] border border-[#F59E0B]/40 text-xs font-bold flex items-center gap-1.5 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset Demo Data
          </button>
        </div>

        <div className="pt-2 border-t border-[#162A42] text-[11px] text-[#64748B] flex items-center justify-between">
          <span>Current active report count in browser storage: <strong className="text-white">{reports.length} records</strong></span>
          <span className="text-[#22C55E] font-mono">Persistent LocalStorage Active</span>
        </div>
      </div>

      {/* Architecture & AI Engine Diagnostics */}
      <div className="bg-[#0B1728] rounded-2xl border border-[#162A42] p-5 shadow-lg space-y-3">
        <div className="flex items-center gap-2">
          <Cpu className="w-4 h-4 text-[#00BFFF]" />
          <h3 className="text-xs font-bold text-white uppercase tracking-wider">
            CivicPulse Engine Diagnostics
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="bg-[#071322] p-3 rounded-xl border border-[#162C47]">
            <span className="text-[10px] text-[#64748B] uppercase font-bold">AI Analysis Subsystem</span>
            <p className="text-white font-semibold mt-1">Multi-Factor Explainable ImpactScore Matrix</p>
            <p className="text-[10px] text-[#38BDF8] mt-0.5">Automated hazard vision & safety keyword heuristics</p>
          </div>

          <div className="bg-[#071322] p-3 rounded-xl border border-[#162C47]">
            <span className="text-[10px] text-[#64748B] uppercase font-bold">Duplicate Detection</span>
            <p className="text-white font-semibold mt-1">CivicCluster Spatial Proximity Index</p>
            <p className="text-[10px] text-[#38BDF8] mt-0.5">Scans 500m proximity & category clusters</p>
          </div>
        </div>
      </div>

    </div>
  );
};
