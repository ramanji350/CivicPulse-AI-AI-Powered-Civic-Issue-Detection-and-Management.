import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Search, 
  Filter, 
  FileText, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  TrendingUp, 
  UserCheck, 
  Edit3, 
  ExternalLink, 
  Upload, 
  Save, 
  X,
  Layers,
  MapPin,
  Calendar,
  Sparkles
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { translations } from '../../utils/translations';
import { CivicReport, ReportStatus, PriorityLevel, IssueCategory } from '../../types';
import { ISSUE_IMAGES } from '../../data/sampleReports';

export const AdminDashboard: React.FC = () => {
  const { 
    reports, 
    updateReportStatus, 
    language, 
    setSelectedReportForProofPath 
  } = useApp();
  const t = translations[language];

  // Filtering states
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedPriority, setSelectedPriority] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Edit / Triage Modal State
  const [editingReport, setEditingReport] = useState<CivicReport | null>(null);
  const [newStatus, setNewStatus] = useState<ReportStatus>('In Progress');
  const [newTeam, setNewTeam] = useState('');
  const [internalNote, setInternalNote] = useState('');
  const [resolutionProofImage, setResolutionProofImage] = useState<string>('');
  const [resolutionNotes, setResolutionNotes] = useState('');
  const [overridePriority, setOverridePriority] = useState<PriorityLevel>('High');

  // Derived Admin stats
  const totalReportsCount = reports.length;
  const unresolvedCount = reports.filter(r => r.timeline[r.timeline.length - 1]?.stage !== 'Resolved').length;
  const highPriorityCount = reports.filter(r => ['High', 'Critical'].includes(r.priority)).length;
  const resolvedCount = reports.filter(r => r.timeline[r.timeline.length - 1]?.stage === 'Resolved').length;

  const filteredReports = reports.filter((rep) => {
    const currentStage = rep.timeline[rep.timeline.length - 1]?.stage || 'Submitted';
    const matchesSearch = 
      rep.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rep.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rep.location.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rep.id.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = selectedStatus === 'all' || currentStage === selectedStatus;
    const matchesPriority = selectedPriority === 'all' || rep.priority === selectedPriority;
    const matchesCategory = selectedCategory === 'all' || rep.category === selectedCategory;

    return matchesSearch && matchesStatus && matchesPriority && matchesCategory;
  });

  const openTriageModal = (rep: CivicReport) => {
    setEditingReport(rep);
    const currentStage = (rep.timeline[rep.timeline.length - 1]?.stage || 'Submitted') as ReportStatus;
    setNewStatus(currentStage);
    setNewTeam(rep.assignedTeam || 'Road Infrastructure Fast-Response Unit #2');
    setInternalNote(rep.internalNotes || '');
    setResolutionProofImage(rep.resolutionImageUrl || (currentStage === 'Resolved' ? ISSUE_IMAGES.potholeAfter : ''));
    setResolutionNotes(rep.resolutionNotes || '');
    setOverridePriority(rep.priority);
  };

  const handleSaveTriage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingReport) return;

    // Default resolution image if resolved
    let finalResolutionImg = resolutionProofImage;
    if (newStatus === 'Resolved' && !finalResolutionImg) {
      finalResolutionImg = editingReport.category === 'garbage' ? ISSUE_IMAGES.garbageAfter :
                           editingReport.category === 'streetlight' ? ISSUE_IMAGES.streetlightAfter :
                           ISSUE_IMAGES.potholeAfter;
    }

    updateReportStatus(editingReport.id, newStatus, {
      assignedTeam: newTeam,
      internalNotes: internalNote,
      resolutionImage: finalResolutionImg,
      resolutionNotes: resolutionNotes || 'Repairs verified by municipal safety dispatch.',
      priority: overridePriority,
    });

    setEditingReport(null);
  };

  const getPriorityBadgeClass = (priority: PriorityLevel) => {
    switch (priority) {
      case 'Critical':
        return 'bg-[#EF4444]/20 text-[#EF4444] border-[#EF4444]/40';
      case 'High':
        return 'bg-[#F59E0B]/20 text-[#F59E0B] border-[#F59E0B]/40';
      case 'Medium':
        return 'bg-[#38BDF8]/20 text-[#38BDF8] border-[#38BDF8]/40';
      default:
        return 'bg-[#22C55E]/20 text-[#22C55E] border-[#22C55E]/40';
    }
  };

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'Resolved':
        return 'bg-[#22C55E]/20 text-[#22C55E] border-[#22C55E]/40';
      case 'In Progress':
        return 'bg-[#00BFFF]/20 text-[#38BDF8] border-[#00BFFF]/40';
      case 'Assigned':
        return 'bg-[#A855F7]/20 text-[#C084FC] border-[#A855F7]/40';
      case 'Under Review':
        return 'bg-[#F59E0B]/20 text-[#F59E0B] border-[#F59E0B]/40';
      default:
        return 'bg-[#9AA4B2]/20 text-[#CBD5E1] border-[#9AA4B2]/40';
    }
  };

  return (
    <div className="max-w-7xl mx-auto py-6 px-4 lg:px-8 space-y-6">
      
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-gradient-to-r from-[#170E28] via-[#0D1829] to-[#0A1628] p-6 rounded-3xl border border-[#A855F7]/30 shadow-xl">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[11px] font-mono px-2.5 py-0.5 rounded-full bg-[#A855F7]/20 text-[#C084FC] border border-[#A855F7]/40 font-bold flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5" />
              MUNICIPAL DISPATCH CONTROL BUREAU
            </span>
          </div>
          <h1 className="text-2xl font-black text-white">
            {t.adminView}
          </h1>
          <p className="text-xs text-[#9AA4B2] mt-1 max-w-xl">
            Triage incoming citizen reports, assign specialized maintenance teams, manage resolution evidence, and sync verified updates in real-time.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-[#22C55E] bg-[#22C55E]/10 border border-[#22C55E]/30 px-3 py-1.5 rounded-xl flex items-center gap-1.5 font-bold">
            <span className="w-2 h-2 rounded-full bg-[#22C55E] animate-ping" />
            Live Dispatch Active
          </span>
        </div>
      </div>

      {/* 4 Overview Statistics Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-[#0B1728] p-5 rounded-2xl border border-[#162A42] shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#9AA4B2]">{t.totalReports}</span>
            <div className="w-8 h-8 rounded-xl bg-[#00BFFF]/15 text-[#00BFFF] flex items-center justify-center">
              <FileText className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-white font-mono">{totalReportsCount}</span>
            <span className="text-[11px] text-[#38BDF8]">registered</span>
          </div>
        </div>

        <div className="bg-[#0B1728] p-5 rounded-2xl border border-[#162A42] shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#9AA4B2]">{t.unresolved}</span>
            <div className="w-8 h-8 rounded-xl bg-[#F59E0B]/15 text-[#F59E0B] flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-[#F59E0B] font-mono">{unresolvedCount}</span>
            <span className="text-[11px] text-[#F59E0B]">pending action</span>
          </div>
        </div>

        <div className="bg-[#0B1728] p-5 rounded-2xl border border-[#162A42] shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#9AA4B2]">{t.highPriority}</span>
            <div className="w-8 h-8 rounded-xl bg-[#EF4444]/15 text-[#EF4444] flex items-center justify-center">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-[#EF4444] font-mono">{highPriorityCount}</span>
            <span className="text-[11px] text-[#EF4444]">High/Critical SLA</span>
          </div>
        </div>

        <div className="bg-[#0B1728] p-5 rounded-2xl border border-[#162A42] shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#9AA4B2]">{t.resolved}</span>
            <div className="w-8 h-8 rounded-xl bg-[#22C55E]/15 text-[#22C55E] flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-[#22C55E] font-mono">{resolvedCount}</span>
            <span className="text-[11px] text-[#22C55E]">sign-off completed</span>
          </div>
        </div>

      </div>

      {/* Filters Bar */}
      <div className="bg-[#0B1728] p-4 rounded-2xl border border-[#162A42] flex flex-col md:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-[#64748B] absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search report ID, location, incident title..."
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-[#071322] border border-[#1A2E46] text-white text-xs placeholder-[#4B5E77] focus:outline-none focus:border-[#00BFFF]"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto flex-wrap">
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-2 rounded-xl bg-[#071322] border border-[#1A2E46] text-white text-xs focus:outline-none focus:border-[#00BFFF]"
          >
            <option value="all">Status: All</option>
            <option value="Submitted">Submitted</option>
            <option value="Under Review">Under Review</option>
            <option value="Assigned">Assigned</option>
            <option value="In Progress">In Progress</option>
            <option value="Resolved">Resolved</option>
          </select>

          <select
            value={selectedPriority}
            onChange={(e) => setSelectedPriority(e.target.value)}
            className="px-3 py-2 rounded-xl bg-[#071322] border border-[#1A2E46] text-white text-xs focus:outline-none focus:border-[#00BFFF]"
          >
            <option value="all">Priority: All</option>
            <option value="Critical">Critical</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>

          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-3 py-2 rounded-xl bg-[#071322] border border-[#1A2E46] text-white text-xs focus:outline-none focus:border-[#00BFFF]"
          >
            <option value="all">Category: All</option>
            <option value="pothole">Potholes & Roads</option>
            <option value="garbage">Waste & Dumpsters</option>
            <option value="streetlight">Streetlights</option>
            <option value="footpath">Footpaths</option>
            <option value="water_leak">Water Leaks</option>
            <option value="other">Other Hazards</option>
          </select>
        </div>
      </div>

      {/* Reports Table */}
      <div className="bg-[#0B1728] rounded-2xl border border-[#162A42] shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            
            <thead className="bg-[#081527] border-b border-[#162A42] text-[11px] text-[#9AA4B2] uppercase font-bold tracking-wider">
              <tr>
                <th className="py-3.5 px-4">Incident / ID</th>
                <th className="py-3.5 px-4">Location</th>
                <th className="py-3.5 px-4">ImpactScore & Priority</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4">Assigned Crew</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-[#122238]">
              {filteredReports.map((rep) => {
                const currentStage = rep.timeline[rep.timeline.length - 1]?.stage || 'Submitted';
                return (
                  <tr key={rep.id} className="hover:bg-[#0E1F36]/60 transition-colors">
                    
                    {/* ID, Thumbnail & Title */}
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-xl overflow-hidden border border-[#1A2E46] bg-[#06111F] flex-shrink-0 flex items-center justify-center">
                          {rep.imageUrl ? (
                            <img src={rep.imageUrl} alt={rep.title} className="w-full h-full object-cover" />
                          ) : (
                            <span className="text-[10px] text-[#64748B]">No photo</span>
                          )}
                        </div>

                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-mono text-xs font-bold text-[#00BFFF]">
                              {rep.id}
                            </span>
                            {rep.duplicateOf && (
                              <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#F59E0B]/20 text-[#F59E0B] font-bold">
                                Duplicate
                              </span>
                            )}
                          </div>
                          <p className="font-bold text-white max-w-xs truncate mt-0.5">
                            {rep.title}
                          </p>
                          <span className="text-[10px] text-[#64748B]">
                            By {rep.citizenName} • {new Date(rep.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    </td>

                    {/* Location */}
                    <td className="py-3.5 px-4 text-[#CBD5E1] max-w-[200px]">
                      <div className="flex items-start gap-1">
                        <MapPin className="w-3.5 h-3.5 text-[#38BDF8] flex-shrink-0 mt-0.5" />
                        <span className="truncate">{rep.location.address}</span>
                      </div>
                    </td>

                    {/* ImpactScore & Priority */}
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${getPriorityBadgeClass(rep.priority)}`}>
                          {rep.priority}
                        </span>
                        <span className="font-mono text-[11px] text-[#00BFFF] font-bold bg-[#00BFFF]/10 px-1.5 py-0.5 rounded">
                          {rep.impactScore} pts
                        </span>
                      </div>
                    </td>

                    {/* Status */}
                    <td className="py-3.5 px-4">
                      <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${getStatusBadgeClass(currentStage)}`}>
                        {currentStage}
                      </span>
                    </td>

                    {/* Assigned Crew */}
                    <td className="py-3.5 px-4 text-[#CBD5E1]">
                      <span className="truncate max-w-[160px] block">
                        {rep.assignedTeam || <span className="text-[#64748B] italic">Unassigned</span>}
                      </span>
                    </td>

                    {/* Actions */}
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => openTriageModal(rep)}
                          className="px-2.5 py-1.5 rounded-lg bg-[#A855F7]/20 hover:bg-[#A855F7]/30 text-[#C084FC] border border-[#A855F7]/40 text-xs font-bold flex items-center gap-1 transition-colors"
                          title="Manage & Dispatch"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>Triage</span>
                        </button>

                        <button
                          onClick={() => setSelectedReportForProofPath(rep)}
                          className="px-2.5 py-1.5 rounded-lg bg-[#101F33] hover:bg-[#15273F] text-[#38BDF8] border border-[#1E3A5F] text-xs font-semibold transition-colors"
                          title="View ProofPath"
                        >
                          Timeline
                        </button>
                      </div>
                    </td>

                  </tr>
                );
              })}
            </tbody>

          </table>
        </div>
      </div>

      {/* TRIAGE / DISPATCH MODAL */}
      {editingReport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="relative w-full max-w-2xl bg-[#0A1728] border border-[#A855F7]/40 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            
            <div className="px-6 py-4 bg-[#0D1C30] border-b border-[#1A2E46] flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <ShieldCheck className="w-5 h-5 text-[#A855F7]" />
                <h3 className="text-base font-bold text-white">
                  Triage & Assign Incident #{editingReport.id}
                </h3>
              </div>
              <button
                onClick={() => setEditingReport(null)}
                className="p-1.5 text-[#9AA4B2] hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveTriage} className="p-6 overflow-y-auto space-y-4">
              
              <div className="bg-[#081424] p-3 rounded-xl border border-[#162C47]">
                <h4 className="text-xs font-bold text-white">{editingReport.title}</h4>
                <p className="text-[11px] text-[#9AA4B2] mt-0.5">{editingReport.location.address}</p>
              </div>

              {/* Status Update Options */}
              <div>
                <label className="block text-xs font-bold text-white mb-1.5">
                  Update Resolution Status
                </label>
                <select
                  value={newStatus}
                  onChange={(e) => setNewStatus(e.target.value as ReportStatus)}
                  className="w-full px-3.5 py-2 rounded-xl bg-[#071322] border border-[#1A2E46] text-white text-xs font-semibold focus:outline-none focus:border-[#A855F7]"
                >
                  <option value="Submitted">1. Submitted (Pending Triage)</option>
                  <option value="Under Review">2. Under Review (Engineering Assessment)</option>
                  <option value="Assigned">3. Assigned (Work Order Dispatched)</option>
                  <option value="In Progress">4. In Progress (Crews On-Site)</option>
                  <option value="Resolved">5. Resolved (Verified Completion Proof)</option>
                </select>
              </div>

              {/* Maintenance Crew Assignment */}
              <div>
                <label className="block text-xs font-bold text-white mb-1.5">
                  Assign Maintenance Crew / Department
                </label>
                <select
                  value={newTeam}
                  onChange={(e) => setNewTeam(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-[#071322] border border-[#1A2E46] text-white text-xs focus:outline-none focus:border-[#A855F7]"
                >
                  <option value="Road Infrastructure Fast-Response Unit #2">Road Infrastructure Fast-Response Unit #2</option>
                  <option value="Municipal Waste & Sanitation Division B">Municipal Waste & Sanitation Division B</option>
                  <option value="Municipal Electrical Grid Services">Municipal Electrical Grid Services</option>
                  <option value="Civil Sidewalk Rehabilitation Corps">Civil Sidewalk Rehabilitation Corps</option>
                  <option value="Municipal Hydro Utilities Emergency Crew">Municipal Hydro Utilities Emergency Crew</option>
                  <option value="Traffic Light & Signal Engineering Team">Traffic Light & Signal Engineering Team</option>
                </select>
              </div>

              {/* Priority Override */}
              <div>
                <label className="block text-xs font-bold text-white mb-1.5">
                  Priority Override
                </label>
                <select
                  value={overridePriority}
                  onChange={(e) => setOverridePriority(e.target.value as PriorityLevel)}
                  className="w-full px-3.5 py-2 rounded-xl bg-[#071322] border border-[#1A2E46] text-white text-xs focus:outline-none focus:border-[#A855F7]"
                >
                  <option value="Critical">Critical Priority</option>
                  <option value="High">High Priority</option>
                  <option value="Medium">Medium Priority</option>
                  <option value="Low">Low Priority</option>
                </select>
              </div>

              {/* Resolution Evidence (If resolved) */}
              {newStatus === 'Resolved' && (
                <div className="bg-[#081527] p-4 rounded-xl border border-[#22C55E]/40 space-y-3">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#22C55E]" />
                    <span className="text-xs font-bold text-white">Resolution Evidence Verification</span>
                  </div>

                  <div>
                    <label className="block text-[11px] text-[#9AA4B2] mb-1">
                      Resolution Proof Photo (Auto-attached verified completion proof):
                    </label>
                    <div className="h-28 rounded-lg overflow-hidden border border-[#162C47] bg-[#06111F]">
                      <img 
                        src={resolutionProofImage || (editingReport.category === 'garbage' ? ISSUE_IMAGES.garbageAfter : ISSUE_IMAGES.potholeAfter)} 
                        alt="Resolution proof" 
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] text-[#9AA4B2] mb-1">
                      Inspector Verification Notes:
                    </label>
                    <input
                      type="text"
                      value={resolutionNotes}
                      onChange={(e) => setResolutionNotes(e.target.value)}
                      placeholder="e.g. Tarmac cured, compaction test passed, signed off by Inspector."
                      className="w-full px-3 py-1.5 rounded-lg bg-[#071322] border border-[#1A2E46] text-white text-xs"
                    />
                  </div>
                </div>
              )}

              {/* Internal Staff Notes */}
              <div>
                <label className="block text-xs font-bold text-white mb-1.5">
                  Internal Staff Notes & Dispatch Instructions
                </label>
                <textarea
                  rows={2}
                  value={internalNote}
                  onChange={(e) => setInternalNote(e.target.value)}
                  placeholder="Notes visible to dispatch crew and recorded on ProofPath..."
                  className="w-full px-3.5 py-2 rounded-xl bg-[#071322] border border-[#1A2E46] text-white text-xs placeholder-[#4B5E77] focus:outline-none focus:border-[#A855F7]"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setEditingReport(null)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-[#9AA4B2] hover:text-white"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#A855F7] to-[#8B5CF6] text-white font-bold text-xs shadow-lg shadow-[#A855F7]/25 flex items-center gap-1.5 hover:opacity-95 transition-all"
                >
                  <Save className="w-4 h-4" />
                  {t.saveChanges}
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
};
