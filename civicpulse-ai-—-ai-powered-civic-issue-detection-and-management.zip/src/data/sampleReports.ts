import { CivicReport } from '../types';

// Crisp, high-contrast SVG illustrations for civic issues (embedded as clean SVG Data URLs)
export const ISSUE_IMAGES = {
  potholeBefore: 'data:image/svg+xml;utf8,' + encodeURIComponent(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 400" width="100%" height="100%">
      <rect width="600" height="400" fill="#0c1626"/>
      <path d="M0 260 L600 260 L600 400 L0 400 Z" fill="#152438"/>
      <!-- Road markings -->
      <line x1="50" y1="330" x2="150" y2="330" stroke="#f59e0b" stroke-width="8" stroke-dasharray="25,25"/>
      <line x1="250" y1="330" x2="350" y2="330" stroke="#f59e0b" stroke-width="8" stroke-dasharray="25,25"/>
      <line x1="450" y1="330" x2="550" y2="330" stroke="#f59e0b" stroke-width="8" stroke-dasharray="25,25"/>
      <!-- Pothole crater -->
      <ellipse cx="300" cy="300" rx="140" ry="60" fill="#050a12"/>
      <ellipse cx="300" cy="305" rx="120" ry="45" fill="#020509"/>
      <path d="M190 295 Q230 270 290 280 T390 290 Q430 320 380 340 T230 330 Z" fill="#000000" stroke="#38bdf8" stroke-width="1.5" stroke-dasharray="4,4"/>
      <!-- Crack lines radiating -->
      <path d="M160 290 L110 265 M150 320 L90 350 M440 285 L510 260 M430 330 L490 365" stroke="#475569" stroke-width="3"/>
      <!-- Warning tag -->
      <rect x="20" y="20" width="170" height="34" rx="6" fill="#ef4444" fill-opacity="0.2" stroke="#ef4444" stroke-width="1"/>
      <text x="35" y="42" fill="#ef4444" font-family="sans-serif" font-size="14" font-weight="bold">CRATER HAZARD</text>
    </svg>
  `),
  potholeAfter: 'data:image/svg+xml;utf8,' + encodeURIComponent(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 400" width="100%" height="100%">
      <rect width="600" height="400" fill="#0c1626"/>
      <path d="M0 260 L600 260 L600 400 L0 400 Z" fill="#1b2a3f"/>
      <!-- Repaired asphalt patch -->
      <ellipse cx="300" cy="300" rx="150" ry="65" fill="#24344d" stroke="#22c55e" stroke-width="2"/>
      <!-- Fresh smooth hot-mix tarmac texture -->
      <path d="M170 300 Q240 285 300 290 T430 300" stroke="#38bdf8" stroke-width="2" stroke-opacity="0.4"/>
      <!-- Road markings repainted -->
      <line x1="50" y1="330" x2="150" y2="330" stroke="#f59e0b" stroke-width="8"/>
      <line x1="250" y1="330" x2="350" y2="330" stroke="#f59e0b" stroke-width="8"/>
      <line x1="450" y1="330" x2="550" y2="330" stroke="#f59e0b" stroke-width="8"/>
      <!-- Verification Stamp -->
      <rect x="20" y="20" width="220" height="34" rx="6" fill="#22c55e" fill-opacity="0.2" stroke="#22c55e" stroke-width="1.5"/>
      <text x="35" y="42" fill="#22c55e" font-family="sans-serif" font-size="14" font-weight="bold">VERIFIED RESOLVED &#x2714;</text>
    </svg>
  `),
  garbageBefore: 'data:image/svg+xml;utf8,' + encodeURIComponent(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 400" width="100%" height="100%">
      <rect width="600" height="400" fill="#091322"/>
      <!-- Pavement ground -->
      <rect y="280" width="600" height="120" fill="#132338"/>
      <!-- Dumpster bin -->
      <rect x="220" y="180" width="160" height="130" rx="8" fill="#1e3a5f" stroke="#38bdf8" stroke-width="2"/>
      <rect x="200" y="165" width="200" height="20" rx="4" fill="#2b4c77"/>
      <!-- Overflowing trash bags and clutter -->
      <circle cx="250" cy="150" r="30" fill="#334155"/>
      <circle cx="310" cy="140" r="35" fill="#475569"/>
      <circle cx="360" cy="155" r="28" fill="#1e293b"/>
      <path d="M170 290 Q200 270 240 290 T190 320 Z" fill="#475569"/>
      <path d="M370 280 Q420 265 440 300 T390 330 Z" fill="#334155"/>
      <!-- Biohazard warning -->
      <rect x="20" y="20" width="180" height="34" rx="6" fill="#f59e0b" fill-opacity="0.2" stroke="#f59e0b" stroke-width="1"/>
      <text x="35" y="42" fill="#f59e0b" font-family="sans-serif" font-size="14" font-weight="bold">OVERFLOW WASTE</text>
    </svg>
  `),
  garbageAfter: 'data:image/svg+xml;utf8,' + encodeURIComponent(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 400" width="100%" height="100%">
      <rect width="600" height="400" fill="#091322"/>
      <rect y="280" width="600" height="120" fill="#172b44"/>
      <!-- Clean sanitized dumpster with closed lid -->
      <rect x="220" y="180" width="160" height="130" rx="8" fill="#1a3b5c" stroke="#22c55e" stroke-width="2"/>
      <rect x="210" y="165" width="180" height="20" rx="4" fill="#22c55e" fill-opacity="0.6"/>
      <!-- Sparkling cleanliness stars -->
      <circle cx="180" cy="240" r="4" fill="#38bdf8"/>
      <circle cx="430" cy="230" r="5" fill="#38bdf8"/>
      <circle cx="300" cy="120" r="6" fill="#22c55e"/>
      <rect x="20" y="20" width="220" height="34" rx="6" fill="#22c55e" fill-opacity="0.2" stroke="#22c55e" stroke-width="1.5"/>
      <text x="35" y="42" fill="#22c55e" font-family="sans-serif" font-size="14" font-weight="bold">SANITIZED &amp; CLEARED &#x2714;</text>
    </svg>
  `),
  streetlightBefore: 'data:image/svg+xml;utf8,' + encodeURIComponent(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 400" width="100%" height="100%">
      <rect width="600" height="400" fill="#040913"/>
      <!-- Street pole -->
      <path d="M285 380 L285 100 Q285 60 330 60 L380 60" fill="none" stroke="#334155" stroke-width="12" stroke-linecap="round"/>
      <polygon points="360,65 400,65 390,85 370,85" fill="#475569"/>
      <!-- Dark warning flickering spark -->
      <circle cx="380" cy="88" r="6" fill="#ef4444"/>
      <path d="M375 95 L385 110 L370 115" stroke="#f59e0b" stroke-width="2" fill="none"/>
      <!-- Ground and darkness -->
      <rect y="340" width="600" height="60" fill="#0a1220"/>
      <rect x="20" y="20" width="180" height="34" rx="6" fill="#ef4444" fill-opacity="0.2" stroke="#ef4444" stroke-width="1"/>
      <text x="35" y="42" fill="#ef4444" font-family="sans-serif" font-size="14" font-weight="bold">DARK ZONE HAZARD</text>
    </svg>
  `),
  streetlightAfter: 'data:image/svg+xml;utf8,' + encodeURIComponent(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 400" width="100%" height="100%">
      <rect width="600" height="400" fill="#071426"/>
      <!-- Glowing lamp beam cone -->
      <polygon points="380,85 120,400 580,400" fill="#00bfff" fill-opacity="0.15"/>
      <path d="M285 380 L285 100 Q285 60 330 60 L380 60" fill="none" stroke="#475569" stroke-width="12" stroke-linecap="round"/>
      <polygon points="360,65 400,65 390,85 370,85" fill="#38bdf8"/>
      <!-- Radiant glow bulb -->
      <circle cx="380" cy="85" r="16" fill="#ffffff"/>
      <circle cx="380" cy="85" r="30" fill="#00bfff" fill-opacity="0.4"/>
      <rect y="340" width="600" height="60" fill="#0e233d"/>
      <rect x="20" y="20" width="220" height="34" rx="6" fill="#22c55e" fill-opacity="0.2" stroke="#22c55e" stroke-width="1.5"/>
      <text x="35" y="42" fill="#22c55e" font-family="sans-serif" font-size="14" font-weight="bold">LED FIXTURE ONLINE &#x2714;</text>
    </svg>
  `),
  footpathBefore: 'data:image/svg+xml;utf8,' + encodeURIComponent(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 400" width="100%" height="100%">
      <rect width="600" height="400" fill="#0c1626"/>
      <rect y="160" width="600" height="240" fill="#1b2a3f"/>
      <!-- Slabs broken -->
      <polygon points="120,200 240,195 230,280 110,270" fill="#2b3e58" stroke="#06111f" stroke-width="4"/>
      <!-- Broken raised slab (trip hazard) -->
      <polygon points="250,185 380,210 370,300 240,275" fill="#3b5274" stroke="#ef4444" stroke-width="3"/>
      <polygon points="390,215 510,220 500,310 380,305" fill="#2b3e58" stroke="#06111f" stroke-width="4"/>
      <!-- Rubble -->
      <circle cx="280" cy="240" r="12" fill="#111c2e"/>
      <circle cx="340" cy="260" r="15" fill="#111c2e"/>
      <rect x="20" y="20" width="190" height="34" rx="6" fill="#ef4444" fill-opacity="0.2" stroke="#ef4444" stroke-width="1"/>
      <text x="35" y="42" fill="#ef4444" font-family="sans-serif" font-size="14" font-weight="bold">TRIP HAZARD SLABS</text>
    </svg>
  `),
  waterLeakBefore: 'data:image/svg+xml;utf8,' + encodeURIComponent(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 400" width="100%" height="100%">
      <rect width="600" height="400" fill="#071322"/>
      <rect y="220" width="600" height="180" fill="#13243a"/>
      <!-- Gushing water fountain -->
      <path d="M280 270 Q300 130 310 110 Q320 130 340 270" fill="none" stroke="#38bdf8" stroke-width="8"/>
      <!-- Splash rings -->
      <ellipse cx="310" cy="275" rx="140" ry="45" fill="#0284c7" fill-opacity="0.4" stroke="#38bdf8" stroke-width="2"/>
      <ellipse cx="310" cy="275" rx="80" ry="25" fill="#38bdf8" fill-opacity="0.6"/>
      <rect x="20" y="20" width="200" height="34" rx="6" fill="#00bfff" fill-opacity="0.2" stroke="#00bfff" stroke-width="1"/>
      <text x="35" y="42" fill="#00bfff" font-family="sans-serif" font-size="14" font-weight="bold">WATER MAIN RUPTURE</text>
    </svg>
  `),
};

export const INITIAL_SAMPLE_REPORTS: CivicReport[] = [
  {
    id: 'CP-2026-8941',
    title: 'Severe Asphalt Crater on 5th Avenue & Metro Corridor',
    description: 'Deep road crater causing vehicles to swerve abruptly into the oncoming lane right next to the metro bus stop. High risk during rush hour traffic.',
    category: 'pothole',
    priority: 'Critical',
    impactScore: 92,
    impactReasons: [
      'High vehicle transit density (arterial metro corridor)',
      'Depth exceeds 14 cm posing immediate suspension damage and collision risk',
      'Pedestrian bus bay proximity under 20 meters'
    ],
    location: {
      address: '5th Ave & Elm Metro Transit Corridor, Sector 4',
      coordinates: { lat: 37.7749, lng: -122.4194 },
      neighborhood: 'Central Transit District'
    },
    imageUrl: ISSUE_IMAGES.potholeBefore,
    createdAt: '2026-10-08T08:30:00Z',
    updatedAt: '2026-10-09T01:15:00Z',
    citizenId: 'user-priya-01',
    citizenName: 'Priya Sharma',
    assignedTeam: 'Road Infrastructure Fast-Response Unit #2',
    internalNotes: 'Tarmac crew dispatched with infrared asphalt patching rig. Work commenced early morning.',
    timeline: [
      {
        id: 't-1',
        stage: 'Submitted',
        title: 'Incident Reported with AI ImpactScore',
        description: 'Report logged by citizen Priya Sharma with photo proof and ImpactScore: 92/100.',
        timestamp: '2026-10-08T08:30:00Z',
        actor: 'Citizen & CivicPulse AI'
      },
      {
        id: 't-2',
        stage: 'Under Review',
        title: 'Dispatch Triage Completed',
        description: 'Municipal engineering dispatcher verified high arterial risk and confirmed Critical classification.',
        timestamp: '2026-10-08T09:10:00Z',
        actor: 'Dispatcher Karen Reed'
      },
      {
        id: 't-3',
        stage: 'Assigned',
        title: 'Assigned to Road Fast-Response Unit #2',
        description: 'Assigned to Chief Engineer David Vance with high urgency dispatch protocol.',
        timestamp: '2026-10-08T11:45:00Z',
        actor: 'Public Works Dispatch'
      },
      {
        id: 't-4',
        stage: 'In Progress',
        title: 'Crews On-Site — Milling & Patching',
        description: 'Traffic cones deployed, asphalt milling commenced for permanent hot-mix patch.',
        timestamp: '2026-10-09T01:15:00Z',
        actor: 'Engineer David Vance'
      }
    ]
  },
  {
    id: 'CP-2026-8812',
    title: 'Overflowing Commercial Dumpster at Central Market Gate 3',
    description: 'Waste container has spilled onto the pedestrian sidewalk for two days. Stray animals gathering and foul odor affecting food vendor stalls.',
    category: 'garbage',
    priority: 'High',
    impactScore: 84,
    impactReasons: [
      'Commercial pedestrian zone with food hygiene implications',
      'Blocked wheelchair access on public sidewalk',
      'Vector attraction hazard (stray animals, flies)'
    ],
    location: {
      address: 'Central Market Gate 3, Commercial Arcade St',
      coordinates: { lat: 37.7785, lng: -122.4140 },
      neighborhood: 'Downtown Market Sector'
    },
    imageUrl: ISSUE_IMAGES.garbageBefore,
    createdAt: '2026-10-08T14:20:00Z',
    updatedAt: '2026-10-08T16:00:00Z',
    citizenId: 'user-priya-01',
    citizenName: 'Priya Sharma',
    assignedTeam: 'Municipal Waste & Sanitation Division B',
    internalNotes: 'Heavy compactor truck scheduled for night collection route with sanitization spray.',
    timeline: [
      {
        id: 't-21',
        stage: 'Submitted',
        title: 'Sanitation Incident Logged',
        description: 'Citizen report uploaded with photo verification.',
        timestamp: '2026-10-08T14:20:00Z',
        actor: 'Priya Sharma'
      },
      {
        id: 't-22',
        stage: 'Under Review',
        title: 'Sanitation Inspector Triage',
        description: 'Classified High Priority due to market food hygiene zone.',
        timestamp: '2026-10-08T14:50:00Z',
        actor: 'Sanitation Supervisor'
      },
      {
        id: 't-23',
        stage: 'Assigned',
        title: 'Assigned to Sanitation Division B',
        description: 'Work order #WM-772 generated for collection truck #14.',
        timestamp: '2026-10-08T16:00:00Z',
        actor: 'Waste Control Desk'
      }
    ]
  },
  {
    id: 'CP-2026-8705',
    title: 'Extinguished High-Mast Streetlight & Dark Safety Corridor',
    description: 'Streetlight pole is completely dark for 3 consecutive nights. Creates a 60-meter blackout zone along the pedestrian park pathway.',
    category: 'streetlight',
    priority: 'Medium',
    impactScore: 68,
    impactReasons: [
      'Nighttime public safety & visibility hazard along park pathway',
      'Electrical short suspected in base connection junction'
    ],
    location: {
      address: 'Oakridge Blvd & Pine Park Walkway, Sector 7',
      coordinates: { lat: 37.7812, lng: -122.4260 },
      neighborhood: 'Oakridge Green Zone'
    },
    imageUrl: ISSUE_IMAGES.streetlightBefore,
    createdAt: '2026-10-07T19:40:00Z',
    updatedAt: '2026-10-08T09:00:00Z',
    citizenId: 'user-john-02',
    citizenName: 'Marcus Chen',
    assignedTeam: 'Municipal Electrical Grid Services',
    internalNotes: 'Capacitor replacement needed on pole #OL-104.',
    timeline: [
      {
        id: 't-31',
        stage: 'Submitted',
        title: 'Dark Zone Hazard Logged',
        description: 'Nighttime report received with coordinates.',
        timestamp: '2026-10-07T19:40:00Z',
        actor: 'Marcus Chen'
      },
      {
        id: 't-32',
        stage: 'Under Review',
        title: 'Smart Grid Audit',
        description: 'Telemetric circuit breaker ping confirmed power drop at circuit branch #12.',
        timestamp: '2026-10-08T09:00:00Z',
        actor: 'Grid Operations'
      }
    ]
  },
  {
    id: 'CP-2026-8519',
    title: 'Fractured Pedestrian Walkway Slabs near School Zone',
    description: 'Uprooted concrete slabs creating severe tripping danger right outside the main gate of Public Elementary School #4.',
    category: 'footpath',
    priority: 'High',
    impactScore: 89,
    impactReasons: [
      'School zone with high volume of children and senior citizens',
      'Raised concrete lip height over 6.5 cm creates severe trip liability'
    ],
    location: {
      address: 'Front Gate, Public Elementary School #4, Maple Ave',
      coordinates: { lat: 37.7710, lng: -122.4110 },
      neighborhood: 'Maple School District'
    },
    imageUrl: ISSUE_IMAGES.footpathBefore,
    resolutionImageUrl: ISSUE_IMAGES.potholeAfter,
    resolutionNotes: 'Concrete slabs realigned and fresh rapid-cure polymer resurfaced. Inspected by Civil Works Inspector Torres.',
    resolvedAt: '2026-10-08T17:30:00Z',
    createdAt: '2026-10-06T10:15:00Z',
    updatedAt: '2026-10-08T17:30:00Z',
    citizenId: 'user-priya-01',
    citizenName: 'Priya Sharma',
    assignedTeam: 'Civil Sidewalk Rehabilitation Corps',
    internalNotes: 'Completed on-schedule within 36 hour target SLA.',
    timeline: [
      {
        id: 't-41',
        stage: 'Submitted',
        title: 'Trip Hazard Reported',
        description: 'Submitted with photo proof.',
        timestamp: '2026-10-06T10:15:00Z',
        actor: 'Priya Sharma'
      },
      {
        id: 't-42',
        stage: 'Under Review',
        title: 'Urgent School Zone Triage',
        description: 'Prioritized due to school proximity.',
        timestamp: '2026-10-06T11:00:00Z',
        actor: 'Safety Officer Mendez'
      },
      {
        id: 't-43',
        stage: 'Assigned',
        title: 'Assigned to Sidewalk Corps',
        description: 'Dispatched crew with concrete levelling gear.',
        timestamp: '2026-10-07T08:00:00Z',
        actor: 'Public Works'
      },
      {
        id: 't-44',
        stage: 'In Progress',
        title: 'Repair Underway',
        description: 'Slabs lifted, tree root trimmed safely, polymer poured.',
        timestamp: '2026-10-07T13:30:00Z',
        actor: 'Sidewalk Corps #3'
      },
      {
        id: 't-45',
        stage: 'Resolved',
        title: 'Inspected & Fully Resolved',
        description: 'Final inspection signed off by Officer Torres. Proof photo uploaded to ProofPath.',
        timestamp: '2026-10-08T17:30:00Z',
        actor: 'Inspector Torres'
      }
    ]
  },
  {
    id: 'CP-2026-8402',
    title: 'Pressurized Water Main Leak Flooding Sidewalk',
    description: 'Subterranean pipe joint rupture flooding the curbside gutter and eroding road embankment near Elm Street intersection.',
    category: 'water_leak',
    priority: 'Critical',
    impactScore: 94,
    impactReasons: [
      'Potable water wastage estimated at 400 liters/hour',
      'Road base soil erosion risk under asphalt',
      'Flooding causing vehicle hydroplaning'
    ],
    location: {
      address: 'Elm Street & 12th Avenue Crossing',
      coordinates: { lat: 37.7690, lng: -122.4230 },
      neighborhood: 'Elm Heights District'
    },
    imageUrl: ISSUE_IMAGES.waterLeakBefore,
    createdAt: '2026-10-08T22:10:00Z',
    updatedAt: '2026-10-09T02:00:00Z',
    citizenId: 'user-sarah-03',
    citizenName: 'Sarah Jenkins',
    assignedTeam: 'Municipal Hydro Utilities Emergency Crew',
    internalNotes: 'Isolation valve partially turned to reduce water pressure while trenching team arrives.',
    timeline: [
      {
        id: 't-51',
        stage: 'Submitted',
        title: 'Flooding Rupture Logged',
        description: 'Citizen report logged with water pressure video snapshot.',
        timestamp: '2026-10-08T22:10:00Z',
        actor: 'Sarah Jenkins'
      },
      {
        id: 't-52',
        stage: 'Under Review',
        title: 'Hydraulic Triage Escalation',
        description: 'Emergency protocol triggered due to road foundation undermining risk.',
        timestamp: '2026-10-08T22:30:00Z',
        actor: 'Hydro Dispatcher Ramos'
      },
      {
        id: 't-53',
        stage: 'Assigned',
        title: 'Emergency Crew En Route',
        description: 'Hydro Emergency Crew #1 dispatched with backhoe and clamp collar.',
        timestamp: '2026-10-08T23:15:00Z',
        actor: 'Municipal Utilities'
      },
      {
        id: 't-54',
        stage: 'In Progress',
        title: 'Excavation & Clamp Fitting',
        description: 'Pressure reduced, pipe exposed and temporary mechanical sleeve secured.',
        timestamp: '2026-10-09T02:00:00Z',
        actor: 'Hydro Foreman Diaz'
      }
    ]
  }
];
