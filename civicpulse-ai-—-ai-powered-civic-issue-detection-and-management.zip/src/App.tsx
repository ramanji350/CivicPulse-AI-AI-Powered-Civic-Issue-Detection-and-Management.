/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/layout/Navbar';
import { DemoWalkthroughBanner } from './components/layout/DemoWalkthroughBanner';
import { AuthPage } from './components/auth/AuthPage';
import { CitizenDashboard } from './components/citizen/CitizenDashboard';
import { ReportIssueForm } from './components/report/ReportIssueForm';
import { MyReportsView } from './components/citizen/MyReportsView';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { InsightsView } from './components/insights/InsightsView';
import { SettingsView } from './components/settings/SettingsView';
import { ProofPathModal } from './components/common/ProofPathModal';
import { CivicAssistChatbot } from './components/chatbot/CivicAssistChatbot';
import { Activity, ShieldCheck, Heart } from 'lucide-react';

const AppContent: React.FC = () => {
  const { 
    currentUser, 
    activeTab, 
    selectedReportForProofPath, 
    setSelectedReportForProofPath 
  } = useApp();

  // If user is not logged in, render full-screen 2-panel AuthPage
  if (!currentUser) {
    return <AuthPage />;
  }

  // Render view based on active navigation tab
  const renderView = () => {
    switch (activeTab) {
      case 'dashboard':
        return <CitizenDashboard />;
      case 'report':
        return <ReportIssueForm />;
      case 'myReports':
        return <MyReportsView />;
      case 'allReports':
        return <AdminDashboard />;
      case 'insights':
        return <InsightsView />;
      case 'settings':
        return <SettingsView />;
      default:
        return currentUser.role === 'admin' ? <AdminDashboard /> : <CitizenDashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-[#06111F] text-[#F5F7FA] flex flex-col relative selection:bg-[#00BFFF]/30 selection:text-white">
      
      {/* Smart-City Background Ambient Grids & Glows */}
      <div className="fixed inset-0 smart-city-grid opacity-35 pointer-events-none z-0" />
      <div className="fixed top-0 left-1/3 w-[500px] h-[500px] bg-[#00BFFF]/5 rounded-full blur-[140px] pointer-events-none z-0" />
      <div className="fixed bottom-0 right-1/4 w-[500px] h-[500px] bg-[#A855F7]/5 rounded-full blur-[140px] pointer-events-none z-0" />

      {/* Demo Walkthrough Banner */}
      <DemoWalkthroughBanner />

      {/* Main Navigation Bar */}
      <Navbar />

      {/* Main Content Area */}
      <main className="flex-1 relative z-10 pb-20">
        {renderView()}
      </main>

      {/* Floating CivicAssist Chatbot */}
      <CivicAssistChatbot />

      {/* Global ProofPath Modal */}
      {selectedReportForProofPath && (
        <ProofPathModal
          report={selectedReportForProofPath}
          onClose={() => setSelectedReportForProofPath(null)}
        />
      )}

      {/* Dark Futuristic Footer */}
      <footer className="relative z-10 bg-[#081424] border-t border-[#14263D] py-6 px-4 text-center text-xs text-[#64748B]">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-[#00BFFF]" />
            <span className="font-bold text-[#CBD5E1]">CivicPulse AI</span>
            <span className="text-[11px] text-[#475569]">| Municipal Incident Intelligence</span>
          </div>
          <p className="text-[11px] text-[#9AA4B2]">
            Report Smart. Prioritize Better. Resolve Together. Built for Smart Cities.
          </p>
          <div className="flex items-center gap-3 text-[11px] text-[#64748B]">
            <span>Web Speech Active</span>
            <span>•</span>
            <span className="text-[#38BDF8]">ProofPath Verified</span>
          </div>
        </div>
      </footer>

    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
